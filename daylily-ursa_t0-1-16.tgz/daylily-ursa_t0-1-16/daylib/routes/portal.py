"""Portal routes for Daylily customer web interface.

Contains HTML template-based routes for:
- Authentication (login, logout, registration, password management)
- Dashboard
- Worksets management
- Files management
- Usage/billing
- Biospecimen management
- Account settings
- Documentation and support
"""

from __future__ import annotations

import logging
import csv
import io
import os
import secrets
from importlib import metadata as importlib_metadata
from importlib import util as importlib_util
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from urllib.parse import quote_plus, urlencode

from botocore.exceptions import ClientError
from fastapi import APIRouter, File, Form, HTTPException, Query, Request, UploadFile, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials
from fastapi.templating import Jinja2Templates

from daylib.config import Settings
from daylily_cognito.oauth import (
    build_authorization_url,
    build_logout_url,
    exchange_authorization_code,
)
from daylib.security import sanitize_for_log
from daylib.s3_utils import RegionAwareS3Client
from daylib.file_registry import (
    BiosampleMetadata as _BiosampleMetadata,
    FileMetadata as _FileMetadata,
    FileRegistration as _FileRegistration,
    SequencingMetadata as _SequencingMetadata,
    detect_file_format as _detect_file_format,
)
from daylib.search import search_portal
from daylib.routes.dependencies import (
    convert_customer_for_template,
    format_file_size,
    APITokenCreateRequest,
    ChangePasswordRequest,
    PortalFileAutoRegisterRequest,
    PortalFileAutoRegisterResponse,
    verify_workset_access,
)
from daylib.workset_state_db import WorksetStateDB, WorksetState

if TYPE_CHECKING:
    from daylily_cognito.auth import CognitoAuth
    from daylib.workset_customer import CustomerManager

LOGGER = logging.getLogger("daylily.routes.portal")


PASSWORD_MIN_LENGTH = 8
PORTAL_REGISTRATION_REGIONS = [
    "us-west-2",
    "us-east-1",
    "ap-south-1",
    "eu-central-1",
]


def _new_error_ref(prefix: str) -> str:
    return f"{prefix}-{secrets.token_hex(4).upper()}"


class PortalDependencies:
    """Container for portal route dependencies.

    Encapsulates all external dependencies needed by portal routes,
    making them easier to inject and test.
    """

    def __init__(
        self,
        state_db: WorksetStateDB,
        templates: Jinja2Templates,
        settings: Settings,
        enable_auth: bool = False,
        cognito_auth: Optional["CognitoAuth"] = None,
        customer_manager: Optional["CustomerManager"] = None,
        file_registry: Optional[Any] = None,
        linked_bucket_manager: Optional[Any] = None,
        biospecimen_registry: Optional[Any] = None,
        manifest_registry: Optional[Any] = None,
    ):
        self.state_db = state_db
        self.templates = templates
        self.settings = settings
        self.enable_auth = enable_auth
        self.cognito_auth = cognito_auth
        self.customer_manager = customer_manager
        self.file_registry = file_registry
        self.linked_bucket_manager = linked_bucket_manager
        self.biospecimen_registry = biospecimen_registry
        self.manifest_registry = manifest_registry
        self.region = settings.get_effective_region()
        self.profile = settings.aws_profile


def _get_customer_for_session(request: Request, deps: PortalDependencies):
    """Get the customer for the currently logged-in user.

    Looks up the customer by the user's email from the session.
    Returns (customer, customer_config) tuple or (None, None) if not found.
    """
    if not deps.customer_manager:
        return None, None

    user_email = None
    if hasattr(request, "session"):
        user_email = request.session.get("user_email")

    if not user_email:
        return None, None

    customer_config = deps.customer_manager.get_customer_by_email(user_email)
    if customer_config:
        return convert_customer_for_template(customer_config), customer_config

    return None, None


def _get_template_context(request: Request, deps: PortalDependencies, **kwargs) -> Dict[str, Any]:
    """Build common template context."""
    cache_bust = str(int(datetime.now().timestamp()))
    context = {
        "request": request,
        "auth_enabled": deps.enable_auth,
        "current_year": datetime.now().year,
        "cache_bust": cache_bust,
    }
    if "customer" in kwargs and kwargs["customer"]:
        context["customer_id"] = kwargs["customer"].customer_id
    if hasattr(request, "session") and request.session.get("user_email"):
        context["user_email"] = request.session.get("user_email")
        context["user_authenticated"] = True
        # Default is_admin from session, but allow explicit override via kwargs
        if "is_admin" not in kwargs:
            context["is_admin"] = request.session.get("is_admin", False)
    # Apply kwargs last so explicit values take precedence
    context.update(kwargs)
    if context.get("user_authenticated") and "search_scope" not in context:
        context["search_scope"] = "all" if bool(context.get("is_admin", False)) else "mine"
    return context


def _require_portal_auth(request: Request) -> Optional[RedirectResponse]:
    """Check if user is authenticated for portal access.

    Returns RedirectResponse to login if not authenticated, None if authenticated.
    """
    if not hasattr(request, "session"):
        return RedirectResponse(url="/portal/login", status_code=302)
    if not request.session.get("user_email"):
        return RedirectResponse(url="/portal/login", status_code=302)
    if not request.session.get("customer_id"):
        LOGGER.warning(f"Session missing customer_id for user {request.session.get('user_email')}")
        return RedirectResponse(url="/portal/login", status_code=302)
    return None


def _require_admin(request: Request) -> None:
    """Require that the current portal session is admin.

    Raises:
        HTTPException: If the user is authenticated but not admin.
    """
    if not bool(request.session.get("is_admin", False)):
        raise HTTPException(status_code=403, detail="Admin access required")


def _validate_password_min_length(password: str) -> Optional[str]:
    """Return an error message if password fails the minimum-length requirement."""
    if len(password) < PASSWORD_MIN_LENGTH:
        return f"Password must be at least {PASSWORD_MIN_LENGTH} characters"
    return None


def _require_portal_api_session(request: Request) -> str:
    """Require a valid portal session for JSON endpoints.

    Returns:
        customer_id: The authenticated customer's ID.
    """
    if not hasattr(request, "session"):
        raise HTTPException(status_code=401, detail="Not authenticated")
    user_email = request.session.get("user_email")
    customer_id = request.session.get("customer_id")
    if not user_email or not customer_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return str(customer_id)


def _get_distribution_version(distribution_name: str) -> Optional[str]:
    """Return installed distribution version, or None when unavailable."""
    try:
        return importlib_metadata.version(distribution_name)
    except importlib_metadata.PackageNotFoundError:
        return None
    except Exception:
        return None


def _is_module_available(module_name: str) -> bool:
    """Return True when an importable module is available in this runtime."""
    return importlib_util.find_spec(module_name) is not None


def _clear_portal_auth_session(request: Request) -> None:
    """Clear portal auth/session keys to avoid stale SSO/login loops."""
    if not hasattr(request, "session"):
        return
    for key in [
        "oauth_state",
        "access_token",
        "id_token",
        "refresh_token",
        "user_email",
        "user_authenticated",
        "customer_id",
        "is_admin",
        "challenge_session",
        "challenge_email",
        "pending_signup_email",
        "pending_signup_access_token",
        "pending_signup_id_token",
        "pending_signup_refresh_token",
    ]:
        request.session.pop(key, None)


def _get_effective_cognito_domain(deps: PortalDependencies) -> Optional[str]:
    """Get Cognito Hosted UI domain from env or settings."""
    return os.getenv("COGNITO_DOMAIN") or deps.settings.cognito_domain


def _get_effective_callback_url(request: Request) -> str:
    """Get OAuth callback URL from env or request context."""
    configured = os.getenv("COGNITO_CALLBACK_URL")
    if configured:
        return configured
    return str(request.url_for("portal_auth_callback"))


def _get_effective_logout_url(request: Request) -> str:
    """Get OAuth logout return URL from env or request context."""
    configured = os.getenv("COGNITO_LOGOUT_URL")
    if configured:
        return configured
    return str(request.base_url)


def _build_signup_url(
    *,
    domain: str,
    client_id: str,
    redirect_uri: str,
    state: str,
    scope: str = "openid email profile",
) -> str:
    """Build Cognito Hosted UI signup URL."""
    query = urlencode(
        {
            "client_id": client_id,
            "response_type": "code",
            "scope": scope,
            "redirect_uri": redirect_uri,
            "state": state,
        }
    )
    return f"https://{domain}/signup?{query}"


def _get_first_customer_converted(deps: PortalDependencies):
    """Helper to get first customer converted for template use."""
    if deps.customer_manager:
        customers = deps.customer_manager.list_customers()
        if customers:
            return convert_customer_for_template(customers[0])
    return None


def _format_bytes(size_bytes: int) -> str:
    """Format bytes to human-readable string."""
    if size_bytes == 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    unit_index = 0
    size = float(size_bytes)
    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024
        unit_index += 1
    return f"{size:.1f} {units[unit_index]}"


def _extract_workset_metrics(workset: Dict[str, Any]) -> Dict[str, Any]:
    """Extract resource usage metrics from workset performance_metrics.

    Populates:
    - storage_gb, storage_bytes, storage_human from post_export_metrics or pre_export_metrics
    - vcpu_hours: Total vCPU seconds from benchmark_data converted to hours
    - memory_gb_hours: Total memory usage (max_rss * duration) from benchmark_data
    - duration_formatted: Pipeline duration as "Xh Ym" from duration_info
    - storage_cost_daily: Daily S3 storage cost ($0.023/GB/month)
    - storage_cost_total: Cumulative storage cost based on days stored
    - storage_days: Number of days data has been stored

    Args:
        workset: Workset dict to extract and enrich with metrics

    Returns:
        The workset dict with resource usage fields added
    """
    from datetime import datetime, timezone

    pm = workset.get("performance_metrics", {})

    # Try post_export_metrics first (new format), fall back to pre_export_metrics (legacy)
    export_metrics = {}
    if pm and isinstance(pm, dict):
        export_metrics = pm.get("post_export_metrics", {})
        if not export_metrics:
            # Backwards compatibility: try pre_export_metrics
            export_metrics = pm.get("pre_export_metrics", {})

    # Extract storage size from export metrics
    size_bytes = 0
    size_human = ""
    if export_metrics and isinstance(export_metrics, dict):
        size_bytes = int(export_metrics.get("analysis_directory_size_bytes", 0) or 0)
        size_human = export_metrics.get("analysis_directory_size_human", "")

    # Populate storage fields
    workset["storage_bytes"] = size_bytes
    workset["storage_gb"] = round(size_bytes / (1024**3), 2) if size_bytes > 0 else 0
    workset["storage_human"] = size_human if size_human else (_format_bytes(size_bytes) if size_bytes > 0 else "")
    workset["storage_available"] = size_bytes > 0

    # Calculate storage costs (S3 Standard: $0.023/GB/month)
    S3_STANDARD_RATE_PER_GB_MONTH = 0.023
    storage_gb = workset["storage_gb"]
    daily_rate = S3_STANDARD_RATE_PER_GB_MONTH / 30.0  # ~$0.000767/GB/day

    workset["storage_cost_daily"] = round(storage_gb * daily_rate, 4) if storage_gb > 0 else 0

    # Calculate days stored since completion
    storage_days = 0
    completed_at = workset.get("completed_at") or workset.get("updated_at")
    if completed_at and workset.get("state") in ("complete", "error", "archived"):
        try:
            if isinstance(completed_at, str):
                # Parse ISO format timestamp
                if completed_at.endswith("Z"):
                    completed_at = completed_at[:-1] + "+00:00"
                completed_dt = datetime.fromisoformat(completed_at)
            else:
                completed_dt = completed_at
            now = datetime.now(timezone.utc)
            storage_days = max(1, (now - completed_dt).days)  # At least 1 day
        except (ValueError, TypeError):
            storage_days = 1

    workset["storage_days"] = storage_days
    workset["storage_cost_total"] = round(workset["storage_cost_daily"] * storage_days, 2) if storage_days > 0 else 0
    workset["storage_class"] = "S3 Standard"  # Default for recent exports

    # Calculate transfer costs based on storage size
    # AWS data transfer pricing (approximate, varies by region)
    TRANSFER_INTERNET_PER_GB = 0.09  # Data transfer out to internet
    TRANSFER_CROSS_REGION_PER_GB = 0.02  # Data transfer to different AWS region
    TRANSFER_SAME_REGION_PER_GB = 0.01  # Data transfer within same region

    workset["transfer_cost_internet"] = round(storage_gb * TRANSFER_INTERNET_PER_GB, 4) if storage_gb > 0 else 0
    workset["transfer_cost_cross_region"] = round(storage_gb * TRANSFER_CROSS_REGION_PER_GB, 4) if storage_gb > 0 else 0
    workset["transfer_cost_same_region"] = round(storage_gb * TRANSFER_SAME_REGION_PER_GB, 4) if storage_gb > 0 else 0

    # Extract vCPU hours and memory GB-hours from benchmark_data
    vcpu_hours = 0.0
    memory_gb_hours = 0.0
    if pm and isinstance(pm, dict):
        benchmark_data = pm.get("benchmark_data", [])
        if benchmark_data and isinstance(benchmark_data, list):
            for entry in benchmark_data:
                if not isinstance(entry, dict):
                    continue
                # cpu_time is in seconds - sum all cpu_time and convert to hours
                try:
                    cpu_time_s = float(entry.get("cpu_time", 0) or 0)
                    vcpu_hours += cpu_time_s / 3600.0
                except (ValueError, TypeError):
                    pass
                # memory: max_rss (in MB) * duration (s) / 3600 / 1024 = GB-hours
                try:
                    max_rss_mb = float(entry.get("max_rss", 0) or 0)
                    duration_s = float(entry.get("s", 0) or 0)
                    memory_gb_hours += (max_rss_mb / 1024.0) * (duration_s / 3600.0)
                except (ValueError, TypeError):
                    pass

    workset["vcpu_hours"] = round(vcpu_hours, 2)
    workset["memory_gb_hours"] = round(memory_gb_hours, 2)

    # Extract duration from duration_info (parsed from Snakemake logs)
    duration_info = pm.get("duration_info", {}) if pm and isinstance(pm, dict) else {}
    duration_seconds = duration_info.get("duration_seconds", 0) if duration_info else 0

    if duration_seconds > 0:
        hours = duration_seconds // 3600
        minutes = (duration_seconds % 3600) // 60
        if hours > 0:
            workset["duration_formatted"] = f"{hours}h {minutes}m"
        else:
            workset["duration_formatted"] = f"{minutes}m"
        workset["duration_seconds"] = duration_seconds
    else:
        workset["duration_formatted"] = None
        workset["duration_seconds"] = 0

    return workset


# Backwards compatibility alias
def _extract_workset_storage(workset: Dict[str, Any]) -> Dict[str, Any]:
    """Alias for _extract_workset_metrics for backwards compatibility."""
    return _extract_workset_metrics(workset)


SEARCH_TYPE_LABELS: Dict[str, str] = {
    "workset": "Worksets",
    "file": "Files",
    "subject": "Subjects",
    "biosample": "Biosamples",
    "library": "Libraries",
    "manifest": "Manifests",
    "cluster": "Clusters",
    "user": "Users",
    "monitor_log": "Monitor Logs",
}


def _query_list(request: Request, key: str) -> List[str]:
    """Parse repeatable query params and comma-separated values."""
    values: List[str] = []
    for raw_value in request.query_params.getlist(key):
        raw = str(raw_value or "").strip()
        if not raw:
            continue
        for part in raw.split(","):
            token = part.strip()
            if token:
                values.append(token)
    return values


def _build_portal_search_filters(request: Request, *, is_admin: bool) -> Dict[str, Any]:
    """Build normalized search filters from request query params."""
    scope_default = "all" if is_admin else "mine"
    scope = str(request.query_params.get("scope") or scope_default).strip().lower()
    limit_raw = str(request.query_params.get("limit_per_type") or "").strip()
    limit_per_type = 20
    if limit_raw:
        try:
            limit_per_type = int(limit_raw)
        except ValueError:
            limit_per_type = 20

    return {
        "scope": scope,
        "types": _query_list(request, "type"),
        "state": str(request.query_params.get("state") or "").strip(),
        "region": str(request.query_params.get("region") or "").strip(),
        "customer": str(request.query_params.get("customer") or "").strip(),
        "tag": _query_list(request, "tag"),
        "file_format": str(request.query_params.get("file_format") or "").strip(),
        "sample_type": str(request.query_params.get("sample_type") or "").strip(),
        "platform": str(request.query_params.get("platform") or "").strip(),
        "limit_per_type": limit_per_type,
    }


def _execute_portal_search(request: Request, deps: PortalDependencies) -> Dict[str, Any]:
    """Run global portal search with request/session-derived context."""
    session_context = {
        "customer_id": request.session.get("customer_id", ""),
        "user_email": request.session.get("user_email", ""),
        "is_admin": bool(request.session.get("is_admin", False)),
    }
    filters = _build_portal_search_filters(request, is_admin=bool(session_context["is_admin"]))
    query = str(request.query_params.get("q") or "").strip()
    return search_portal(
        query=query,
        filters=filters,
        session_context=session_context,
        deps={
            "state_db": deps.state_db,
            "settings": deps.settings,
            "customer_manager": deps.customer_manager,
            "file_registry": deps.file_registry,
            "biospecimen_registry": deps.biospecimen_registry,
            "manifest_registry": deps.manifest_registry,
        },
    )


def create_portal_router(deps: PortalDependencies) -> APIRouter:
    """Create portal router with injected dependencies.

    Args:
        deps: PortalDependencies container with all required dependencies

    Returns:
        Configured APIRouter with portal routes
    """
    router = APIRouter(tags=["portal"])

    # ========== Public Legal Pages ==========

    @router.get("/terms", response_class=HTMLResponse)
    async def terms_of_service(request: Request):
        """Public Terms of Service page."""
        return deps.templates.TemplateResponse(
            request,
            "legal/terms.html",
            _get_template_context(request, deps),
        )

    @router.get("/privacy", response_class=HTMLResponse)
    async def privacy_policy(request: Request):
        """Public Privacy Policy page."""
        return deps.templates.TemplateResponse(
            request,
            "legal/privacy.html",
            _get_template_context(request, deps),
        )

    # ========== Dashboard ==========

    @router.get("/portal", response_class=HTMLResponse)
    async def portal_dashboard(request: Request):
        """Customer portal dashboard."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect

        customer = None
        customer_id = None
        worksets = []
        stats: Dict[str, Any] = {
            "active_worksets": 0,
            "completed_worksets": 0,
            "storage_used_gb": 0,
            "storage_percent": 0,
            "max_storage_gb": 500,
            "cost_this_month": 0,
            "in_progress_worksets": 0,
            "ready_worksets": 0,
            "error_worksets": 0,
            "registered_files": 0,
            "total_file_size_gb": 0,
            "total_file_size_bytes": 0,
        }

        if deps.customer_manager:
            customer, customer_config = _get_customer_for_session(request, deps)
            if customer:
                customer_id = customer.customer_id
            elif deps.settings.demo_mode:
                customers = deps.customer_manager.list_customers()
                if customers:
                    customer_raw = customers[0]
                    customer = convert_customer_for_template(customer_raw)
                    customer_id = customer_raw.customer_id

            if customer_id:
                all_worksets = []
                for ws_state in WorksetState:
                    batch = deps.state_db.list_worksets_by_state(ws_state, limit=100)

                    # SECURITY: portal dashboard must only show worksets the user can access.
                    session_user_email = request.session.get("user_email") if hasattr(request, "session") else None
                    session_is_admin = bool(request.session.get("is_admin", False)) if hasattr(request, "session") else False
                    batch = [
                        ws
                        for ws in batch
                        if verify_workset_access(
                            ws,
                            customer_id=customer_id,
                            user_email=session_user_email,
                            is_admin=session_is_admin,
                        )
                    ]
                    all_worksets.extend(batch)
                worksets = all_worksets[:10]

                stats["in_progress_worksets"] = len([w for w in all_worksets if w.get("state") == "in_progress"])
                stats["ready_worksets"] = len([w for w in all_worksets if w.get("state") == "ready"])
                stats["completed_worksets"] = len([w for w in all_worksets if w.get("state") == "complete"])
                stats["error_worksets"] = len([w for w in all_worksets if w.get("state") == "error"])
                stats["active_worksets"] = stats["in_progress_worksets"]

                # Calculate actual costs and storage from completed worksets with performance metrics
                # Cost calculation constants
                S3_STORAGE_COST_PER_GB_MONTH = 0.023  # S3 Standard storage
                TRANSFER_COST_PER_GB = 0.10  # Placeholder transfer cost

                total_actual_cost = 0.0
                total_workset_storage_bytes = 0
                completed = [w for w in all_worksets if w.get("state") == "complete"]
                for ws in completed:
                    pm = ws.get("performance_metrics", {})
                    if pm and isinstance(pm, dict):
                        cost_summary = pm.get("cost_summary", {})
                        if cost_summary and isinstance(cost_summary, dict):
                            total_actual_cost += float(cost_summary.get("total_cost", 0))
                        # Aggregate workset storage (try post_export_metrics first, fall back to pre_export_metrics)
                        export_metrics = pm.get("post_export_metrics", {}) or pm.get("pre_export_metrics", {})
                        if export_metrics and isinstance(export_metrics, dict):
                            total_workset_storage_bytes += int(export_metrics.get("analysis_directory_size_bytes", 0) or 0)
                    else:
                        # Fall back to estimated cost if no performance metrics
                        total_actual_cost += float(ws.get("cost_usd", 0) or ws.get("metadata", {}).get("cost_usd", 0) or 0)

                # Calculate cost breakdown
                workset_storage_gb = total_workset_storage_bytes / (1024**3)
                storage_cost = workset_storage_gb * S3_STORAGE_COST_PER_GB_MONTH
                transfer_cost = workset_storage_gb * TRANSFER_COST_PER_GB
                total_cost = total_actual_cost + storage_cost + transfer_cost

                stats["compute_cost_usd"] = round(total_actual_cost, 2)
                stats["storage_cost_usd"] = round(storage_cost, 4)
                stats["transfer_cost_usd"] = round(transfer_cost, 4)
                stats["cost_this_month"] = round(total_cost, 2)
                stats["actual_cost_total"] = round(total_actual_cost, 2)
                stats["workset_storage_bytes"] = total_workset_storage_bytes
                stats["workset_storage_gb"] = round(workset_storage_gb, 2)
                stats["workset_storage_human"] = _format_bytes(total_workset_storage_bytes)

                if deps.file_registry:
                    try:
                        customer_files = deps.file_registry.list_customer_files(customer_id, limit=1000)
                        stats["registered_files"] = len(customer_files)
                        total_bytes = sum(f.file_metadata.file_size_bytes for f in customer_files if f.file_metadata)
                        stats["total_file_size_bytes"] = total_bytes
                        stats["total_file_size_gb"] = round(total_bytes / (1024**3), 2)
                    except Exception as e:
                        LOGGER.warning(f"Failed to get file statistics: {e}")

        return deps.templates.TemplateResponse(
            request,
            "dashboard.html",
            _get_template_context(request, deps, customer=customer, worksets=worksets, stats=stats, active_page="dashboard"),
        )

    # ========== Global Search Routes ==========

    @router.get("/portal/search", response_class=HTMLResponse)
    async def portal_search(request: Request):
        """Global federated search results page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect

        customer, _ = _get_customer_for_session(request, deps)
        search_data = _execute_portal_search(request, deps)

        displayed_types = list(search_data.get("types", []))
        selected_types = set(displayed_types)
        type_facets = [
            {
                "key": item_type,
                "label": SEARCH_TYPE_LABELS.get(item_type, item_type.replace("_", " ").title()),
                "count": int(search_data.get("returned_counts", {}).get(item_type, 0)),
                "selected": item_type in selected_types,
            }
            for item_type in displayed_types
        ]

        filters = search_data.get("filters", {})
        has_query = bool(str(search_data.get("query") or "").strip())
        has_filters = any(
            [
                filters.get("types"),
                filters.get("state"),
                filters.get("region"),
                filters.get("customer"),
                filters.get("tags"),
                filters.get("file_format"),
                filters.get("sample_type"),
                filters.get("platform"),
            ]
        )

        return deps.templates.TemplateResponse(
            request,
            "search/results.html",
            _get_template_context(
                request,
                deps,
                customer=customer,
                search=search_data,
                type_facets=type_facets,
                type_labels=SEARCH_TYPE_LABELS,
                has_query=has_query,
                has_filters=has_filters,
                active_page="search",
                search_scope=search_data.get("scope", "mine"),
            ),
        )

    @router.get("/api/portal/search")
    async def portal_api_search(request: Request):
        """JSON global search endpoint used by portal clients."""
        _require_portal_api_session(request)
        return JSONResponse(_execute_portal_search(request, deps))

    # ========== Authentication Routes ==========

    @router.get("/portal/login", response_class=HTMLResponse)
    async def portal_login(
        request: Request,
        error: Optional[str] = None,
        success: Optional[str] = None,
        sso: bool = False,
        reset: bool = False,
        signup: bool = False,
    ):
        """Login page (or Hosted UI redirect when configured)."""
        if request.session.get("user_email") and request.session.get("customer_id"):
            return RedirectResponse(url="/portal/", status_code=302)

        if reset:
            _clear_portal_auth_session(request)
            success = success or "Session cleared. Please try signing in again."

        domain = _get_effective_cognito_domain(deps)
        client_id = deps.settings.cognito_app_client_id
        hosted_ui_enabled = bool(deps.enable_auth and deps.cognito_auth and domain and client_id)
        hosted_ui_domain = domain or ""
        hosted_ui_client_id = client_id or ""

        if hosted_ui_enabled and not error and not success:
            if sso or signup or not request.query_params:
                _clear_portal_auth_session(request)
                callback_url = _get_effective_callback_url(request)
                state_token = secrets.token_urlsafe(24)
                request.session["oauth_state"] = state_token

                auth_url = (
                    _build_signup_url(
                        domain=hosted_ui_domain,
                        client_id=hosted_ui_client_id,
                        redirect_uri=callback_url,
                        state=state_token,
                    )
                    if signup
                    else build_authorization_url(
                        domain=hosted_ui_domain,
                        client_id=hosted_ui_client_id,
                        redirect_uri=callback_url,
                        state=state_token,
                    )
                )
                return RedirectResponse(url=auth_url, status_code=302)

        if hosted_ui_enabled and (error or success):
            # Ensure failures don't leave sticky OAuth/session state.
            _clear_portal_auth_session(request)

        if hosted_ui_enabled and (sso or signup):
            _clear_portal_auth_session(request)
            callback_url = _get_effective_callback_url(request)
            state_token = secrets.token_urlsafe(24)
            request.session["oauth_state"] = state_token

            auth_url = (
                _build_signup_url(
                    domain=hosted_ui_domain,
                    client_id=hosted_ui_client_id,
                    redirect_uri=callback_url,
                    state=state_token,
                )
                if signup
                else build_authorization_url(
                    domain=hosted_ui_domain,
                    client_id=hosted_ui_client_id,
                    redirect_uri=callback_url,
                    state=state_token,
                )
            )
            return RedirectResponse(url=auth_url, status_code=302)

        return deps.templates.TemplateResponse(
            request,
            "auth/login.html",
            _get_template_context(
                request,
                deps,
                error=error,
                success=success,
                hosted_ui_enabled=hosted_ui_enabled,
                sso_login_url="/portal/login?sso=1",
                sso_signup_url="/portal/login?signup=1",
                reset_login_url="/portal/login?reset=1",
            ),
        )

    @router.get("/auth/callback", response_class=RedirectResponse)
    async def portal_auth_callback(
        request: Request,
        code: Optional[str] = None,
        state: Optional[str] = None,
        error: Optional[str] = None,
        error_description: Optional[str] = None,
    ):
        """Handle Cognito Hosted UI callback and establish a portal session."""
        if not deps.enable_auth or not deps.cognito_auth:
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Authentication+not+configured", status_code=302)

        if error:
            detail = error_description or error
            _clear_portal_auth_session(request)
            return RedirectResponse(url=f"/portal/login?error={quote_plus(detail)}", status_code=302)

        expected_state = request.session.pop("oauth_state", None)
        if not expected_state or state != expected_state:
            LOGGER.warning("OAuth callback state mismatch")
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Invalid+login+state", status_code=302)

        domain = _get_effective_cognito_domain(deps)
        client_id = deps.settings.cognito_app_client_id
        callback_url = _get_effective_callback_url(request)
        if not domain or not client_id:
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Cognito+OAuth+not+configured", status_code=302)
        if not code:
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Missing+authorization+code", status_code=302)

        try:
            token_result = exchange_authorization_code(
                domain=domain,
                client_id=client_id,
                code=code,
                redirect_uri=callback_url,
                client_secret=deps.settings.cognito_app_client_secret,
            )
        except Exception as e:
            LOGGER.error("OAuth code exchange failed: %s", e)
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Token+exchange+failed", status_code=302)

        access_token = token_result.get("access_token")
        id_token = token_result.get("id_token")
        if not access_token or not id_token:
            LOGGER.error("OAuth callback missing required tokens")
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Invalid+token+response", status_code=302)

        try:
            # Validate access token against Cognito JWKS + app client audience.
            access_claims = deps.cognito_auth.get_current_user(
                HTTPAuthorizationCredentials(scheme="Bearer", credentials=access_token)
            )
        except Exception as e:
            LOGGER.error("Failed to validate access_token from callback: %s", e)
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Invalid+access+token", status_code=302)

        # Hosted UI returns the most reliable user identity in id_token claims.
        email: Optional[str] = None
        token_customer_id: Optional[str] = None
        try:
            from jose import jwt as jose_jwt

            id_claims = jose_jwt.get_unverified_claims(str(id_token))
            email_claim = id_claims.get("email")
            if isinstance(email_claim, str) and email_claim:
                email = email_claim
            customer_claim = id_claims.get("custom:customer_id") or id_claims.get("customer_id")
            if isinstance(customer_claim, str) and customer_claim:
                token_customer_id = customer_claim
        except Exception as e:
            LOGGER.warning("Failed to decode id_token claims: %s", e)

        # Fallback claims from access token if id_token claims are unavailable.
        if not email:
            email = access_claims.get("email") or access_claims.get("username") or access_claims.get("cognito:username")
        if not token_customer_id:
            token_customer_id = access_claims.get("custom:customer_id") or access_claims.get("customer_id")

        if not email:
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Email+claim+missing", status_code=302)

        customer = deps.customer_manager.get_customer_by_email(email) if deps.customer_manager else None
        if not customer and deps.customer_manager and token_customer_id:
            customer = deps.customer_manager.get_customer_config(str(token_customer_id))

        if deps.customer_manager and not customer:
            LOGGER.warning("OAuth login for %s did not map to a customer", sanitize_for_log(email))
            request.session["pending_signup_email"] = email
            return RedirectResponse(
                url="/portal/register?success=Authenticated+email+verified.+Complete+account+setup",
                status_code=302,
            )
        if not customer and not token_customer_id:
            LOGGER.warning("OAuth login for %s missing customer_id claim", sanitize_for_log(email))
            _clear_portal_auth_session(request)
            return RedirectResponse(url="/portal/login?error=Missing+customer+mapping", status_code=302)

        request.session["access_token"] = access_token
        request.session["user_email"] = email
        request.session["user_authenticated"] = True
        request.session["customer_id"] = customer.customer_id if customer else str(token_customer_id)
        request.session["is_admin"] = bool(customer.is_admin) if customer else False

        LOGGER.info("OAuth login successful for %s", sanitize_for_log(email))
        return RedirectResponse(url="/portal/", status_code=302)

    @router.post("/portal/login")
    async def portal_login_submit(request: Request, email: str = Form(...), password: str = Form(...)):
        """Handle login form submission with proper authentication."""
        LOGGER.debug(f"portal_login_submit: Login attempt for email: {email}")

        # Validate email domain against whitelist
        domain_valid, domain_error = deps.settings.validate_email_domain(email)
        if not domain_valid:
            LOGGER.warning(f"Login blocked for {email}: {domain_error}")
            return RedirectResponse(url=f"/portal/login?error={domain_error.replace(' ', '+')}", status_code=302)

        if not deps.customer_manager:
            if not deps.enable_auth:
                LOGGER.warning("portal_login_submit: No customer manager; creating demo session for %s", email)
                request.session["user_email"] = email
                request.session["user_authenticated"] = True
                request.session["customer_id"] = "demo-customer"
                request.session["is_admin"] = True
                return RedirectResponse(url="/portal/", status_code=302)
            LOGGER.error("portal_login_submit: Customer manager not configured")
            return RedirectResponse(url="/portal/login?error=Authentication+not+configured", status_code=302)

        customer = deps.customer_manager.get_customer_by_email(email)
        if not customer:
            LOGGER.warning(f"portal_login_submit: Login attempt for non-existent customer: {email}")
            return RedirectResponse(url="/portal/login?error=Invalid+email+or+password", status_code=302)

        if deps.cognito_auth:
            try:
                LOGGER.debug(f"portal_login_submit: Authenticating with Cognito for: {email}")
                auth_result = deps.cognito_auth.authenticate(email, password)

                if "challenge" in auth_result:
                    challenge_name = auth_result["challenge"]
                    LOGGER.info(f"portal_login_submit: Challenge required for {email}: {challenge_name}")
                    if challenge_name == "NEW_PASSWORD_REQUIRED":
                        request.session["challenge_session"] = auth_result["session"]
                        request.session["challenge_email"] = email
                        return RedirectResponse(url="/portal/change-password?reason=temporary", status_code=302)
                    else:
                        LOGGER.error(f"portal_login_submit: Unsupported challenge: {challenge_name}")
                        return RedirectResponse(url=f"/portal/login?error=Authentication+challenge+required:+{challenge_name}", status_code=302)

                request.session["access_token"] = auth_result["access_token"]
                LOGGER.info(f"portal_login_submit: Cognito authentication successful for: {email}")
            except ValueError as e:
                LOGGER.warning(f"portal_login_submit: Cognito authentication failed for {email}: {e}")
                return RedirectResponse(url="/portal/login?error=Invalid+email+or+password", status_code=302)
            except Exception as e:
                LOGGER.error(f"portal_login_submit: Cognito authentication error for {email}: {e}")
                return RedirectResponse(url="/portal/login?error=Authentication+service+error", status_code=302)
        else:
            LOGGER.warning("portal_login_submit: Cognito not configured - allowing login for registered customer %s WITHOUT password validation", email)

        LOGGER.debug(f"portal_login_submit: Setting session for authenticated user: {email}")
        request.session["user_email"] = email
        request.session["user_authenticated"] = True
        request.session["customer_id"] = customer.customer_id
        request.session["is_admin"] = customer.is_admin
        LOGGER.info(f"portal_login_submit: Login successful for customer {customer.customer_id} ({email})")
        return RedirectResponse(url="/portal/", status_code=302)

    @router.get("/portal/logout", response_class=RedirectResponse)
    async def portal_logout(request: Request):
        """Logout and redirect to login page.

        Thoroughly clears all session data to prevent stale state.
        """
        user_email = request.session.get("user_email", "unknown")
        LOGGER.info(f"Logging out user: {user_email}")

        # Explicitly clear all session keys (more thorough than just .clear())
        for key in list(request.session.keys()):
            del request.session[key]

        # Also call clear() to ensure complete cleanup
        request.session.clear()

        LOGGER.info(f"Session cleared for user: {user_email}")

        domain = _get_effective_cognito_domain(deps)
        client_id = deps.settings.cognito_app_client_id
        if deps.enable_auth and domain and client_id:
            logout_url = build_logout_url(
                domain=domain,
                client_id=client_id,
                logout_uri=_get_effective_logout_url(request),
            )
            return RedirectResponse(url=logout_url, status_code=302)

        return RedirectResponse(url="/portal/login?success=You+have+been+logged+out", status_code=302)

    @router.get("/portal/forgot-password", response_class=HTMLResponse)
    async def portal_forgot_password(request: Request, error: Optional[str] = None, success: Optional[str] = None):
        """Forgot password page."""
        return deps.templates.TemplateResponse(
            request,
            "auth/forgot_password.html",
            _get_template_context(request, deps, error=error, success=success),
        )

    @router.post("/portal/forgot-password")
    async def portal_forgot_password_submit(request: Request, email: str = Form(...)):
        """Handle forgot password form submission."""
        if not deps.cognito_auth:
            return RedirectResponse(url="/portal/forgot-password?error=Password+reset+not+available", status_code=302)
        try:
            deps.cognito_auth.forgot_password(email)
            LOGGER.info(f"Password reset initiated for {email}")
            return RedirectResponse(url="/portal/reset-password?email=" + email, status_code=302)
        except ValueError as e:
            LOGGER.warning(f"Forgot password error for {email}: {e}")
            return RedirectResponse(url=f"/portal/forgot-password?error={str(e)}", status_code=302)
        except Exception as e:
            LOGGER.error(f"Forgot password error for {email}: {e}")
            return RedirectResponse(url="/portal/forgot-password?error=Password+reset+failed", status_code=302)

    @router.get("/portal/reset-password", response_class=HTMLResponse)
    async def portal_reset_password(request: Request, email: Optional[str] = None, error: Optional[str] = None, success: Optional[str] = None):
        """Reset password page."""
        return deps.templates.TemplateResponse(
            request,
            "auth/reset_password.html",
            _get_template_context(request, deps, email=email, error=error, success=success),
        )

    @router.post("/portal/reset-password")
    async def portal_reset_password_submit(request: Request, email: str = Form(...), code: str = Form(...), password: str = Form(...), confirm_password: str = Form(...)):
        """Handle reset password form submission."""
        if not deps.cognito_auth:
            return RedirectResponse(url="/portal/reset-password?error=Password+reset+not+available", status_code=302)
        min_len_error = _validate_password_min_length(password)
        if min_len_error:
            return RedirectResponse(
                url=f"/portal/reset-password?email={quote_plus(email)}&error={quote_plus(min_len_error)}",
                status_code=302,
            )
        if password != confirm_password:
            return RedirectResponse(url=f"/portal/reset-password?email={quote_plus(email)}&error=Passwords+do+not+match", status_code=302)
        try:
            deps.cognito_auth.confirm_forgot_password(email, code, password)
            LOGGER.info("Password reset successful for %s", sanitize_for_log(email))
            return RedirectResponse(url="/portal/login?success=Password+reset+successful.+Please+log+in", status_code=302)
        except ValueError as e:
            LOGGER.warning("Reset password error for %s: %s", sanitize_for_log(email), e)
            return RedirectResponse(url=f"/portal/reset-password?email={quote_plus(email)}&error={quote_plus(str(e))}", status_code=302)
        except Exception as e:
            LOGGER.error(f"Reset password error for {email}: {e}")
            return RedirectResponse(url=f"/portal/reset-password?email={email}&error=Password+reset+failed", status_code=302)

    @router.get("/portal/change-password", response_class=HTMLResponse)
    async def portal_change_password(request: Request, reason: Optional[str] = None, error: Optional[str] = None, success: Optional[str] = None):
        """Change password page (for NEW_PASSWORD_REQUIRED challenge)."""
        if not request.session.get("challenge_session"):
            return RedirectResponse(url="/portal/login?error=Session+expired.+Please+log+in+again", status_code=302)
        email = request.session.get("challenge_email", "")
        return deps.templates.TemplateResponse(
            request,
            "auth/change_password.html",
            _get_template_context(request, deps, email=email, reason=reason, error=error, success=success),
        )

    @router.post("/portal/change-password")
    async def portal_change_password_submit(request: Request, new_password: str = Form(...), confirm_password: str = Form(...)):
        """Handle change password form submission (NEW_PASSWORD_REQUIRED challenge)."""
        if not deps.cognito_auth:
            return RedirectResponse(url="/portal/login?error=Authentication+not+available", status_code=302)
        session = request.session.get("challenge_session")
        email = request.session.get("challenge_email")
        if not session or not email:
            return RedirectResponse(url="/portal/login?error=Session+expired.+Please+log+in+again", status_code=302)
        min_len_error = _validate_password_min_length(new_password)
        if min_len_error:
            return RedirectResponse(
                url=f"/portal/change-password?error={min_len_error.replace(' ', '+')}",
                status_code=302,
            )
        if new_password != confirm_password:
            return RedirectResponse(url="/portal/change-password?error=Passwords+do+not+match", status_code=302)
        try:
            tokens = deps.cognito_auth.respond_to_new_password_challenge(email, new_password, session)
            request.session.pop("challenge_session", None)
            request.session.pop("challenge_email", None)
            customer = deps.customer_manager.get_customer_by_email(email) if deps.customer_manager else None
            if not customer:
                LOGGER.error(f"Customer not found for {email} after password change")
                return RedirectResponse(url="/portal/login?error=Account+not+found", status_code=302)
            request.session["access_token"] = tokens["access_token"]
            request.session["user_email"] = email
            request.session["user_authenticated"] = True
            request.session["customer_id"] = customer.customer_id
            request.session["is_admin"] = customer.is_admin
            LOGGER.info(f"Password changed successfully for {email}, user logged in")
            return RedirectResponse(url="/portal/?success=Password+changed+successfully", status_code=302)
        except ValueError as e:
            LOGGER.warning(f"Password change error for {email}: {e}")
            return RedirectResponse(url=f"/portal/change-password?error={str(e)}", status_code=302)
        except Exception as e:
            LOGGER.error(f"Password change error for {email}: {e}")
            return RedirectResponse(url="/portal/change-password?error=Password+change+failed", status_code=302)

    @router.get("/portal/register", response_class=HTMLResponse)
    async def portal_register(request: Request, error: Optional[str] = None, success: Optional[str] = None):
        """Registration page."""
        # Registration region selection is intentionally limited to a curated set.
        allowed_regions = PORTAL_REGISTRATION_REGIONS
        configured_region = deps.settings.get_effective_region() if deps.settings else allowed_regions[0]
        default_region = configured_region if configured_region in allowed_regions else allowed_regions[0]
        pending_signup_email = request.session.get("pending_signup_email")
        if deps.enable_auth and deps.cognito_auth and not pending_signup_email:
            return RedirectResponse(url="/portal/login?error=Please+sign+in+first", status_code=302)
        return deps.templates.TemplateResponse(
            request,
            "auth/register.html",
            _get_template_context(
                request, deps,
                error=error,
                success=success,
                allowed_regions=allowed_regions,
                default_region=default_region,
                pending_signup_email=pending_signup_email,
            ),
        )

    @router.post("/portal/register", response_class=HTMLResponse)
    async def portal_register_submit(
        request: Request,
        customer_name: str = Form(...),
        email: Optional[str] = Form(None),
        max_concurrent_worksets: int = Form(10),
        max_storage_gb: int = Form(500),
        billing_account_id: Optional[str] = Form(None),
        cost_center: Optional[str] = Form(None),
        s3_option: str = Form("auto"),
        custom_s3_bucket: Optional[str] = Form(None),
        bucket_region: Optional[str] = Form(None),
    ):
        """Handle registration form submission."""
        if not deps.customer_manager:
            return deps.templates.TemplateResponse(
                request, "auth/register.html",
                _get_template_context(request, deps, error="Customer management not configured"),
            )

        resolved_email = (email or "").strip()
        if deps.enable_auth and deps.cognito_auth:
            resolved_email = str(request.session.get("pending_signup_email") or "").strip()
            if not resolved_email:
                return RedirectResponse(url="/portal/login?error=Please+sign+in+first", status_code=302)
        if not resolved_email:
            return deps.templates.TemplateResponse(
                request,
                "auth/register.html",
                _get_template_context(
                    request,
                    deps,
                    error="Email is required",
                    allowed_regions=PORTAL_REGISTRATION_REGIONS,
                    default_region=PORTAL_REGISTRATION_REGIONS[0],
                    pending_signup_email=request.session.get("pending_signup_email"),
                ),
            )

        # Validate email domain against whitelist
        domain_valid, domain_error = deps.settings.validate_email_domain(resolved_email)
        if not domain_valid:
            LOGGER.warning(f"Registration blocked for {resolved_email}: {domain_error}")
            return deps.templates.TemplateResponse(
                request, "auth/register.html",
                _get_template_context(
                    request,
                    deps,
                    error=domain_error,
                    allowed_regions=PORTAL_REGISTRATION_REGIONS,
                    default_region=PORTAL_REGISTRATION_REGIONS[0],
                    pending_signup_email=request.session.get("pending_signup_email"),
                ),
            )

        try:
            custom_bucket = None
            effective_bucket_region = bucket_region if s3_option == "auto" else None
            if effective_bucket_region and effective_bucket_region not in PORTAL_REGISTRATION_REGIONS:
                return deps.templates.TemplateResponse(
                    request,
                    "auth/register.html",
                    _get_template_context(
                        request,
                        deps,
                        error="Invalid bucket region selected",
                        allowed_regions=PORTAL_REGISTRATION_REGIONS,
                        default_region=PORTAL_REGISTRATION_REGIONS[0],
                        pending_signup_email=request.session.get("pending_signup_email"),
                    ),
                )
            if s3_option == "byob" and custom_s3_bucket:
                custom_bucket = custom_s3_bucket.strip()
                if custom_bucket:
                    from daylib.s3_bucket_validator import S3BucketValidator
                    validator = S3BucketValidator(region=deps.region, profile=deps.profile)
                    result = validator.validate_bucket(custom_bucket)
                    if not result.is_valid:
                        error_msg = f"S3 bucket validation failed: {'; '.join(result.errors)}"
                        return deps.templates.TemplateResponse(
                            request, "auth/register.html",
                            _get_template_context(request, deps, error=error_msg),
                        )
            config = deps.customer_manager.onboard_customer(
                customer_name=customer_name,
                email=resolved_email,
                max_concurrent_worksets=max_concurrent_worksets,
                max_storage_gb=max_storage_gb,
                billing_account_id=billing_account_id,
                cost_center=cost_center,
                custom_s3_bucket=custom_bucket,
                bucket_region=effective_bucket_region,
            )
            LOGGER.info(f"Registration: enable_auth={deps.enable_auth}, cognito_auth={'SET' if deps.cognito_auth else 'NONE'}")
            if deps.enable_auth and deps.cognito_auth:
                LOGGER.info("Registration: Cognito account already exists for %s; skipping user creation", resolved_email)
            else:
                LOGGER.warning(f"Skipping Cognito user creation: enable_auth={deps.enable_auth}, cognito_auth={'SET' if deps.cognito_auth else 'NONE'}")
            bucket_info = f" Your S3 bucket: {config.s3_bucket}." if config.s3_bucket else ""
            if not deps.enable_auth:
                LOGGER.info(f"Auto-logging in new customer {config.customer_id} ({resolved_email}) in no-auth mode")
                request.session["user_email"] = resolved_email
                request.session["user_authenticated"] = True
                request.session["customer_id"] = config.customer_id
                request.session["is_admin"] = False
                success_msg = f"✅ Account created! Customer ID: {config.customer_id}.{bucket_info} Welcome!"
                return RedirectResponse(url=f"/portal/?success={success_msg}", status_code=302)
            else:
                request.session.pop("pending_signup_email", None)
                request.session.pop("pending_signup_access_token", None)
                request.session.pop("pending_signup_id_token", None)
                request.session.pop("pending_signup_refresh_token", None)
                # Re-enter Hosted UI login so Cognito session can issue fresh tokens
                # and map into the newly created customer account.
                return RedirectResponse(url="/portal/login?sso=1", status_code=302)
        except Exception:
            error_ref = _new_error_ref("REG")
            LOGGER.exception(
                "Registration failed [error_ref=%s, email=%s]",
                error_ref,
                sanitize_for_log(resolved_email),
            )
            return deps.templates.TemplateResponse(
                request, "auth/register.html",
                _get_template_context(
                    request,
                    deps,
                    error="Unable to create account right now. Please try again.",
                    error_code=error_ref,
                    allowed_regions=PORTAL_REGISTRATION_REGIONS,
                    default_region=PORTAL_REGISTRATION_REGIONS[0],
                    pending_signup_email=request.session.get("pending_signup_email"),
                ),
            )

    # ========== Portal JSON Auth Endpoints (used by /portal/account UI) ==========

    @router.post("/api/v1/auth/change-password")
    async def portal_api_change_password(request: Request, payload: ChangePasswordRequest):
        """Change the current user's password via portal session."""
        _require_portal_api_session(request)
        if not deps.cognito_auth:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Password change not available")
        access_token = request.session.get("access_token")
        if not access_token:
            raise HTTPException(status_code=401, detail="Session expired; please log in again")

        min_len_error = _validate_password_min_length(payload.new_password)
        if min_len_error:
            raise HTTPException(status_code=400, detail=min_len_error)

        try:
            deps.cognito_auth.change_password(
                access_token=str(access_token),
                old_password=payload.current_password,
                new_password=payload.new_password,
            )
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

        return {"ok": True}

    @router.get("/api/v1/auth/tokens")
    async def portal_api_list_tokens(request: Request):
        """List API tokens for the current customer (metadata only)."""
        customer_id = _require_portal_api_session(request)
        if not deps.customer_manager:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Token management not configured")
        return deps.customer_manager.list_api_tokens(customer_id)

    @router.post("/api/v1/auth/tokens")
    async def portal_api_create_token(request: Request, payload: APITokenCreateRequest):
        """Create a new API token and return the secret once."""
        customer_id = _require_portal_api_session(request)
        if not deps.customer_manager:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Token management not configured")

        try:
            result = deps.customer_manager.add_api_token(customer_id, name=payload.name, expiry_days=payload.expiry_days)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

        return {"token": result.get("secret"), "token_meta": result.get("token")}

    @router.delete("/api/v1/auth/tokens/{token_id}")
    async def portal_api_revoke_token(request: Request, token_id: str):
        """Revoke an API token for the current customer."""
        customer_id = _require_portal_api_session(request)
        if not deps.customer_manager:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Token management not configured")

        revoked = deps.customer_manager.revoke_api_token(customer_id, token_id)
        if not revoked:
            raise HTTPException(status_code=404, detail="Token not found")
        return {"revoked": True}

    # ========== Worksets Routes ==========

    # Create region-aware S3 client for portal operations (supports cross-region buckets)
    _portal_s3_client = RegionAwareS3Client(
        default_region=deps.region,
        profile=deps.profile,
    )

    def _get_s3_sentinel_status(bucket: str, prefix: str) -> str:
        """Get workset status from S3 sentinel files.

        Priority order:
        1. daylily.complete -> complete
        2. daylily.error -> error
        3. daylily.in_progress -> in_progress
        4. daylily.ignore -> ignored
        5. daylily.ready -> ready
        6. No sentinels -> unknown
        """
        # Sentinel file names
        sentinels = {
            "daylily.complete": "complete",
            "daylily.error": "error",
            "daylily.in_progress": "in_progress",
            "daylily.ignore": "ignored",
            "daylily.ready": "ready",
        }

        # Normalize prefix
        if not prefix.endswith("/"):
            prefix = prefix + "/"

        try:
            # Use region-aware S3 client to handle cross-region buckets
            response = _portal_s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, MaxKeys=100)
            found_sentinels = set()
            for obj in response.get("Contents", []):
                key = obj["Key"]
                filename = key.split("/")[-1]
                if filename in sentinels:
                    found_sentinels.add(filename)

            # Return in priority order
            for sentinel_file, status in sentinels.items():
                if sentinel_file in found_sentinels:
                    return status
            return "unknown"
        except Exception:
            return "error"

    @router.get("/portal/worksets", response_class=HTMLResponse)
    async def portal_worksets(
        request: Request,
        page: int = 1,
        status: str = "",
        type: str = "",
        search: str = "",
        sort: str = "created_desc",
    ):
        """Worksets list page (excludes archived and deleted worksets).

        Supports filtering by:
        - status: Filter by workset state (ready, queued, in_progress, complete, error, etc.)
        - type: Filter by workset type (clinical, ruo, lsmc)
        - search: Free text search across workset name and metadata
        - sort: Sort order (created_desc, created_asc, status)
        """
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, customer_config = _get_customer_for_session(request, deps)
        worksets = []

        # Get customer_id for filtering (security: only show customer's own worksets)
        session_customer_id = None
        if customer:
            session_customer_id = customer.customer_id
        if not session_customer_id:
            LOGGER.warning("No customer_id in session - returning empty workset list")
            # Return empty list if no customer context (security)
            return deps.templates.TemplateResponse(
                request,
                "worksets/list.html",
                _get_template_context(
                    request, deps,
                    customer=customer,
                    worksets=[],
                    current_page=1,
                    total_pages=1,
                    total_count=0,
                    filter_status=status,
                    filter_type=type,
                    filter_search=search,
                    filter_sort=sort,
                    active_page="worksets",
                ),
            )

        # Determine which states to query based on status filter
        excluded_states = {WorksetState.ARCHIVED, WorksetState.DELETED}
        if status:
            # Filter by specific status
            try:
                target_state = WorksetState(status)
                if target_state not in excluded_states:
                    batch = deps.state_db.list_worksets_by_state(target_state, limit=500)
                    worksets.extend(batch)
            except ValueError:
                # Invalid status, return empty
                pass
        else:
            # Get all non-excluded states
            for ws_state in WorksetState:
                if ws_state in excluded_states:
                    continue
                batch = deps.state_db.list_worksets_by_state(ws_state, limit=100)
                worksets.extend(batch)

        # SECURITY: Filter to only worksets the user can access
        session_user_email = request.session.get("user_email") if hasattr(request, "session") else None
        session_is_admin = bool(request.session.get("is_admin", False)) if hasattr(request, "session") else False
        worksets = [
            w
            for w in worksets
            if verify_workset_access(
                w,
                customer_id=session_customer_id,
                user_email=session_user_email,
                is_admin=session_is_admin,
            )
        ]

        # Process worksets and apply additional filters
        filtered_worksets = []
        search_lower = search.lower().strip() if search else ""
        type_filter = type.lower().strip() if type else ""

        for ws in worksets:
            metadata = ws.get("metadata", {})
            if isinstance(metadata, dict):
                ws["sample_count"] = metadata.get("sample_count", 0)
                ws["pipeline_type"] = metadata.get("pipeline_type", "germline")
                ws["workset_type"] = metadata.get("workset_type", ws.get("workset_type", "ruo"))
            else:
                ws["sample_count"] = 0
                ws["pipeline_type"] = "germline"
                ws["workset_type"] = ws.get("workset_type", "ruo")

            # Apply type filter
            if type_filter:
                ws_type = (ws.get("workset_type") or "ruo").lower()
                if ws_type != type_filter:
                    continue

            # Apply search filter
            if search_lower:
                searchable = " ".join([
                    ws.get("workset_id", ""),
                    ws.get("name", ""),
                    ws.get("workset_type", ""),
                    ws.get("pipeline_type", ""),
                    str(metadata.get("workset_name", "")),
                    str(metadata.get("notification_email", "")),
                ]).lower()
                if search_lower not in searchable:
                    continue

            # Add S3 sentinel status
            bucket = ws.get("bucket", "")
            prefix = ws.get("prefix", "")
            if bucket and prefix:
                ws["s3_status"] = _get_s3_sentinel_status(bucket, prefix)
            else:
                ws["s3_status"] = "unknown"

            # Extract actual compute cost from performance_metrics if available
            compute_cost = 0.0
            is_actual_cost = False
            pm = ws.get("performance_metrics", {})
            if pm and isinstance(pm, dict):
                cost_summary = pm.get("cost_summary", {})
                if cost_summary and isinstance(cost_summary, dict):
                    actual_cost = cost_summary.get("total_cost")
                    if actual_cost is not None and actual_cost > 0:
                        compute_cost = float(actual_cost)
                        is_actual_cost = True

            # Fall back to estimated cost
            if compute_cost == 0:
                compute_cost = float(ws.get("cost_usd", 0) or 0)
                if compute_cost == 0 and isinstance(metadata, dict):
                    compute_cost = float(metadata.get("cost_usd", 0) or metadata.get("estimated_cost_usd", 0) or 0)

            ws["compute_cost"] = compute_cost
            ws["is_actual_cost"] = is_actual_cost

            # Extract storage size from performance_metrics
            _extract_workset_storage(ws)

            filtered_worksets.append(ws)

        # Sort worksets
        if sort == "created_asc":
            filtered_worksets.sort(key=lambda w: w.get("created_at", ""), reverse=False)
        elif sort == "status":
            filtered_worksets.sort(key=lambda w: w.get("state", ""))
        else:  # created_desc (default)
            filtered_worksets.sort(key=lambda w: w.get("created_at", ""), reverse=True)

        # Paginate
        per_page = 20
        total_count = len(filtered_worksets)
        total_pages = max(1, (total_count + per_page - 1) // per_page)
        page = max(1, min(page, total_pages))
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_worksets = filtered_worksets[start_idx:end_idx]

        return deps.templates.TemplateResponse(
            request,
            "worksets/list.html",
            _get_template_context(
                request, deps,
                customer=customer,
                worksets=paginated_worksets,
                current_page=page,
                total_pages=total_pages,
                total_count=total_count,
                filter_status=status,
                filter_type=type,
                filter_search=search,
                filter_sort=sort,
                active_page="worksets",
            ),
        )

    @router.get("/portal/worksets/new", response_class=HTMLResponse)
    async def portal_worksets_new(request: Request):
        """New workset submission page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        return deps.templates.TemplateResponse(
            request,
            "worksets/new.html",
            _get_template_context(request, deps, customer=customer, active_page="worksets"),
        )

    @router.get("/portal/worksets/archived", response_class=HTMLResponse)
    async def portal_worksets_archived(request: Request):
        """Archived worksets page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        archived_worksets = []

        # Get customer_id for filtering (security: only show customer's own worksets)
        session_customer_id = None
        if customer:
            session_customer_id = customer.customer_id

        if session_customer_id:
            all_archived = deps.state_db.list_archived_worksets(limit=500)
            LOGGER.info("Found %d total archived worksets in TapDB", len(all_archived))

            # SECURITY: Filter to only worksets the user can access
            session_user_email = request.session.get("user_email") if hasattr(request, "session") else None
            session_is_admin = bool(request.session.get("is_admin", False)) if hasattr(request, "session") else False
            archived_worksets = [
                w
                for w in all_archived
                if verify_workset_access(
                    w,
                    customer_id=session_customer_id,
                    user_email=session_user_email,
                    is_admin=session_is_admin,
                )
            ]
            LOGGER.info("After customer_id filter: %d archived worksets", len(archived_worksets))
        else:
            LOGGER.warning("No customer_id in session - returning empty archived workset list")
        # Ensure workset_type is available for each archived workset
        for ws in archived_worksets:
            metadata = ws.get("metadata", {})
            if isinstance(metadata, dict):
                ws["workset_type"] = metadata.get("workset_type", ws.get("workset_type", "ruo"))
                ws["pipeline_type"] = metadata.get("pipeline_type", "germline")
                ws["sample_count"] = metadata.get("sample_count", 0)
            else:
                ws["workset_type"] = ws.get("workset_type", "ruo")
                ws["pipeline_type"] = "germline"
                ws["sample_count"] = 0
        return deps.templates.TemplateResponse(
            request,
            "worksets/archived.html",
            _get_template_context(request, deps, customer=customer, worksets=archived_worksets, active_page="worksets"),
        )

    @router.get("/portal/worksets/{workset_id}", response_class=HTMLResponse)
    async def portal_workset_detail(request: Request, workset_id: str):
        """Workset detail page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        workset = deps.state_db.get_workset(workset_id)
        if not workset:
            raise HTTPException(status_code=404, detail="Workset not found")
        customer, _ = _get_customer_for_session(request, deps)

        # SECURITY: Verify workset access before displaying
        session_user_email = request.session.get("user_email") if hasattr(request, "session") else None
        session_is_admin = bool(request.session.get("is_admin", False)) if hasattr(request, "session") else False
        if customer and not verify_workset_access(
            workset,
            customer_id=customer.customer_id,
            user_email=session_user_email,
            is_admin=session_is_admin,
        ):
            LOGGER.warning(
                "Access denied: customer %s attempted to view workset %s owned by %s",
                sanitize_for_log(customer.customer_id),
                sanitize_for_log(workset_id),
                sanitize_for_log(workset.get("customer_id", "unknown")),
            )
            raise HTTPException(status_code=404, detail="Workset not found")
        metadata = workset.get("metadata", {})
        if metadata:
            if "samples" in metadata and "samples" not in workset:
                workset["samples"] = metadata["samples"]
            for field in ["workset_name", "pipeline_type", "reference_genome", "notification_email", "enable_qc", "archive_results", "sample_count"]:
                if field in metadata and field not in workset:
                    workset[field] = metadata[field]

        # Extract storage size from performance_metrics
        _extract_workset_storage(workset)

        return deps.templates.TemplateResponse(
            request,
            "worksets/detail.html",
            _get_template_context(request, deps, customer=customer, workset=workset, active_page="worksets"),
        )

    @router.get("/portal/worksets/{workset_id}/download")
    async def portal_workset_download(request: Request, workset_id: str):
        """Download workset results as a presigned URL redirect."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        workset = deps.state_db.get_workset(workset_id)
        if not workset:
            raise HTTPException(status_code=404, detail="Workset not found")

        # SECURITY: Verify workset access before allowing download
        customer, _ = _get_customer_for_session(request, deps)
        session_user_email = request.session.get("user_email") if hasattr(request, "session") else None
        session_is_admin = bool(request.session.get("is_admin", False)) if hasattr(request, "session") else False
        if customer and not verify_workset_access(
            workset,
            customer_id=customer.customer_id,
            user_email=session_user_email,
            is_admin=session_is_admin,
        ):
            LOGGER.warning(
                "Access denied: customer %s attempted to download workset %s",
                sanitize_for_log(customer.customer_id),
                sanitize_for_log(workset_id),
            )
            raise HTTPException(status_code=404, detail="Workset not found")


        if workset.get("state") != "complete":
            raise HTTPException(
                status_code=400,
                detail=f"Workset is not complete (current state: {workset.get('state')})",
            )

        bucket = workset.get("bucket")
        if not bucket or not isinstance(bucket, str):
            raise HTTPException(status_code=400, detail="No results bucket available for this workset")
        prefix = workset.get("prefix", "").rstrip("/")
        results_prefix = f"{prefix}/results/" if prefix else "results/"
        try:

            response = _portal_s3_client.list_objects_v2(
                Bucket=bucket,
                Prefix=results_prefix,
                MaxKeys=100,
            )
            result_files = []
            for obj in response.get("Contents", []):
                key = obj["Key"]
                filename = key.split("/")[-1]
                if filename and not filename.startswith("."):
                    result_files.append({"key": key, "filename": filename, "size": obj.get("Size", 0)})
            if not result_files:
                raise HTTPException(status_code=404, detail="No result files found for this workset")

            main_results = [
                f
                for f in result_files
                if f["filename"].endswith((".vcf", ".vcf.gz", ".bam", ".cram", ".html"))
            ]
            download_file = main_results[0] if main_results else result_files[0]
            presigned_url = _portal_s3_client.generate_presigned_url(
                "get_object",
                Params={
                    "Bucket": bucket,
                    "Key": download_file["key"],
                    "ResponseContentDisposition": f'attachment; filename="{download_file["filename"]}"',
                },
                ExpiresIn=3600,
            )
            return RedirectResponse(url=presigned_url, status_code=302)
        except HTTPException:
            raise
        except Exception as e:
            LOGGER.error(f"Error generating download for workset {workset_id}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to generate download: {str(e)}")

    @router.get("/portal/worksets/{workset_id}/results/browse", response_class=HTMLResponse)
    async def portal_workset_results_browse(request: Request, workset_id: str, prefix: str = ""):
        """Browse workset results in S3."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        workset = deps.state_db.get_workset(workset_id)
        if not workset:
            raise HTTPException(status_code=404, detail="Workset not found")

        # SECURITY: Verify workset access before allowing browse
        session_user_email = request.session.get("user_email") if hasattr(request, "session") else None
        session_is_admin = bool(request.session.get("is_admin", False)) if hasattr(request, "session") else False
        if customer and not verify_workset_access(
            workset,
            customer_id=customer.customer_id,
            user_email=session_user_email,
            is_admin=session_is_admin,
        ):
            LOGGER.warning(
                "Access denied: customer %s attempted to browse workset %s results",
                sanitize_for_log(customer.customer_id),
                sanitize_for_log(workset_id),
            )
            raise HTTPException(status_code=404, detail="Workset not found")

        # Get results S3 URI
        results_uri = workset.get("results_s3_uri")
        if not results_uri:
            raise HTTPException(status_code=400, detail="No results location available for this workset")

        # Parse S3 URI: s3://bucket/prefix/path
        if not results_uri.startswith("s3://"):
            raise HTTPException(status_code=400, detail="Invalid results URI format")
        uri_parts = results_uri[5:].split("/", 1)
        bucket = uri_parts[0]
        base_prefix = uri_parts[1].rstrip("/") + "/" if len(uri_parts) > 1 else ""

        # Combine base prefix with browsed prefix
        current_prefix = base_prefix + prefix if prefix else base_prefix

        items = []
        breadcrumbs = []
        parent_prefix = None

        # Calculate parent prefix for navigation
        if prefix:
            parts = prefix.rstrip("/").split("/")
            if len(parts) > 1:
                parent_prefix = "/".join(parts[:-1]) + "/"
            else:
                parent_prefix = ""

        try:
            # List objects with delimiter to get folders
            paginator = _portal_s3_client.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=bucket, Prefix=current_prefix, Delimiter="/"):
                # Add folders (common prefixes)
                for cp in page.get("CommonPrefixes", []):
                    folder_key = cp["Prefix"]
                    # Get relative name from base_prefix
                    relative_key = folder_key[len(base_prefix):] if folder_key.startswith(base_prefix) else folder_key
                    folder_name = relative_key.rstrip("/").split("/")[-1]
                    if folder_name and not folder_name.startswith("."):
                        items.append({
                            "name": folder_name,
                            "key": relative_key,
                            "is_folder": True,
                            "size_bytes": None,
                            "last_modified": None,
                            "file_format": None,
                        })

                # Add files
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    # Skip the prefix itself
                    if key == current_prefix:
                        continue
                    relative_key = key[len(base_prefix):] if key.startswith(base_prefix) else key
                    filename = key.split("/")[-1]
                    if filename and not filename.startswith("."):
                        # Determine file format
                        file_format = None
                        if filename.endswith((".fastq", ".fastq.gz", ".fq", ".fq.gz")):
                            file_format = "fastq"
                        elif filename.endswith((".bam", ".bam.bai")):
                            file_format = "bam"
                        elif filename.endswith((".vcf", ".vcf.gz", ".vcf.gz.tbi")):
                            file_format = "vcf"
                        elif filename.endswith((".cram", ".cram.crai")):
                            file_format = "cram"
                        elif filename.endswith(".html"):
                            file_format = "html"
                        elif filename.endswith(".pdf"):
                            file_format = "pdf"
                        elif filename.endswith((".tsv", ".csv")):
                            file_format = "table"

                        items.append({
                            "name": filename,
                            "key": relative_key,
                            "full_key": key,
                            "is_folder": False,
                            "size_bytes": obj.get("Size", 0),
                            "last_modified": obj.get("LastModified").isoformat() if obj.get("LastModified") else None,
                            "file_format": file_format,
                        })
        except Exception as e:
            LOGGER.warning(f"Failed to browse results for {workset_id}: {e}")

        # Build breadcrumbs from prefix
        if prefix:
            parts = prefix.rstrip("/").split("/")
            for i, part in enumerate(parts):
                breadcrumbs.append({"name": part, "prefix": "/".join(parts[:i + 1]) + "/"})

        return deps.templates.TemplateResponse(
            request,
            "worksets/results_browse.html",
            _get_template_context(
                request, deps,
                customer=customer,
                workset=workset,
                items=items,
                breadcrumbs=breadcrumbs,
                current_prefix=prefix,
                parent_prefix=parent_prefix,
                results_uri=results_uri,
                active_page="worksets",
            ),
        )

    @router.get("/portal/worksets/{workset_id}/results/download")
    async def portal_workset_results_download(request: Request, workset_id: str, key: str = Query(...)):
        """Download a file from workset results."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        workset = deps.state_db.get_workset(workset_id)
        if not workset:
            raise HTTPException(status_code=404, detail="Workset not found")

        # SECURITY: Verify workset access before allowing download
        customer, _ = _get_customer_for_session(request, deps)
        session_user_email = request.session.get("user_email") if hasattr(request, "session") else None
        session_is_admin = bool(request.session.get("is_admin", False)) if hasattr(request, "session") else False
        if customer and not verify_workset_access(
            workset,
            customer_id=customer.customer_id,
            user_email=session_user_email,
            is_admin=session_is_admin,
        ):
            LOGGER.warning(
                "Access denied: customer %s attempted to download from workset %s",
                sanitize_for_log(customer.customer_id),
                sanitize_for_log(workset_id),
            )
            raise HTTPException(status_code=404, detail="Workset not found")

        results_uri = workset.get("results_s3_uri")
        if not results_uri:
            raise HTTPException(status_code=400, detail="No results location available")

        # Parse S3 URI
        if not results_uri.startswith("s3://"):
            raise HTTPException(status_code=400, detail="Invalid results URI format")
        uri_parts = results_uri[5:].split("/", 1)
        bucket = uri_parts[0]
        base_prefix = uri_parts[1].rstrip("/") + "/" if len(uri_parts) > 1 else ""

        # Full S3 key
        full_key = base_prefix + key


        try:
            filename = key.split("/")[-1]
            presigned_url = _portal_s3_client.generate_presigned_url(
                "get_object",
                Params={
                    "Bucket": bucket,
                    "Key": full_key,
                    "ResponseContentDisposition": f'attachment; filename="{filename}"',
                },
                ExpiresIn=3600,
            )
            return RedirectResponse(url=presigned_url, status_code=302)
        except Exception as e:
            LOGGER.error(f"Error generating download URL for {workset_id}/{key}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to generate download: {str(e)}")

    # ========== Manifest Generator Routes ==========

    @router.get("/portal/yaml-generator", response_class=HTMLResponse)
    async def portal_yaml_generator(request: Request):
        """Redirect to manifest-generator."""
        return RedirectResponse(url="/portal/manifest-generator", status_code=302)

    @router.get("/portal/manifest-generator", response_class=HTMLResponse)
    async def portal_manifest_generator(request: Request):
        """Manifest/YAML generator page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        return deps.templates.TemplateResponse(
            request,
            "manifest_generator.html",
            _get_template_context(request, deps, customer=customer, active_page="manifest"),
        )

    # ========== Files Routes ==========

    @router.get("/portal/files", response_class=HTMLResponse)
    async def portal_files(request: Request, prefix: str = "", subject_id: str = "", biosample_id: str = ""):
        """File registry page - main file management interface."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        files = []
        stats = {"total_files": 0, "total_size": 0, "unique_subjects": 0, "unique_biosamples": 0}
        buckets = []
        if deps.file_registry and customer:
            customer_id = customer.customer_id
            try:
                if subject_id:
                    files = deps.file_registry.search_files_by_tag(customer_id, f"subject:{subject_id}")
                elif biosample_id:
                    files = deps.file_registry.search_files_by_tag(customer_id, f"biosample:{biosample_id}")
                else:
                    # Fetch all files (use high limit to get complete list for display/filtering)
                    file_registrations = deps.file_registry.list_customer_files(customer_id, limit=10000)

                    def parse_s3_uri(s3_uri):
                        """Parse s3://bucket/key into (bucket, key)."""
                        if s3_uri and s3_uri.startswith("s3://"):
                            parts = s3_uri[5:].split("/", 1)
                            return parts[0], parts[1] if len(parts) > 1 else ""
                        return "", ""

                    files = []
                    for f in file_registrations:
                        s3_uri = f.file_metadata.s3_uri if f.file_metadata else ""
                        bucket, key = parse_s3_uri(s3_uri)
                        registered_at = f.registered_at
                        if isinstance(registered_at, str):
                            registered_at_str = registered_at
                        elif hasattr(registered_at, 'isoformat'):
                            registered_at_str = registered_at.isoformat()
                        else:
                            registered_at_str = None
                        files.append({
                            "file_id": f.file_id,
                            "customer_id": f.customer_id,
                            "s3_bucket": bucket,
                            "s3_key": key,
                            "s3_uri": s3_uri,
                            "filename": key.split("/")[-1] if key else "",
                            "file_size_bytes": f.file_metadata.file_size_bytes if f.file_metadata else 0,
                            "size": f.file_metadata.file_size_bytes if f.file_metadata else 0,
                            "size_formatted": format_file_size(f.file_metadata.file_size_bytes) if f.file_metadata else "0 B",
                            "file_format": f.file_metadata.file_format if f.file_metadata else "unknown",
                            "file_type": f.file_metadata.file_format if f.file_metadata else "unknown",
                            "subject_id": f.biosample_metadata.subject_id if f.biosample_metadata else None,
                            "biosample_id": f.biosample_metadata.biosample_id if f.biosample_metadata else None,
                            "sample_type": f.biosample_metadata.sample_type if f.biosample_metadata else None,
                            "sequencing_platform": f.sequencing_metadata.platform if f.sequencing_metadata else None,
                            "tags": f.tags if f.tags else [],
                            "registered_at": registered_at_str,
                            "workset_count": 0,  # TODO: Add workset count lookup
                        })
                stats["total_files"] = len(files)
                stats["total_size"] = sum(f.get("size", 0) for f in files)
                stats["unique_subjects"] = len(set(f.get("subject_id") for f in files if f.get("subject_id")))
                stats["unique_biosamples"] = len(set(f.get("biosample_id") for f in files if f.get("biosample_id")))
            except Exception as e:
                LOGGER.warning(f"Failed to load files: {e}")
        if deps.linked_bucket_manager and customer:
            try:
                linked_buckets = deps.linked_bucket_manager.list_customer_buckets(customer.customer_id)
                buckets = [{"bucket_id": b.bucket_id, "bucket_name": b.bucket_name, "display_name": b.display_name} for b in linked_buckets]
            except Exception as e:
                LOGGER.warning(f"Failed to load buckets: {e}")
        return deps.templates.TemplateResponse(
            request,
            "files/index.html",
            _get_template_context(request, deps, customer=customer, files=files, stats=stats, buckets=buckets, prefix=prefix, subject_id=subject_id, biosample_id=biosample_id, active_page="files"),
        )

    @router.get("/portal/files/buckets", response_class=HTMLResponse)
    async def portal_files_buckets(request: Request):
        """Linked buckets management page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        buckets = []
        if deps.linked_bucket_manager and customer:
            try:
                linked_buckets = deps.linked_bucket_manager.list_customer_buckets(customer.customer_id)
                buckets = [
                    {"bucket_id": b.bucket_id, "bucket_name": b.bucket_name, "bucket_type": b.bucket_type, "display_name": b.display_name,
                     "description": b.description, "is_validated": b.is_validated, "can_read": b.can_read, "can_write": b.can_write,
                     "can_list": b.can_list, "read_only": b.read_only, "region": b.region,
                     "prefix_restriction": b.prefix_restriction,
                     "linked_at": b.linked_at.isoformat() if hasattr(b.linked_at, 'isoformat') else b.linked_at}
                    for b in linked_buckets
                ]
            except Exception as e:
                LOGGER.warning(f"Failed to load buckets: {e}")
        return deps.templates.TemplateResponse(
            request,
            "files/buckets.html",
            _get_template_context(request, deps, customer=customer, buckets=buckets, active_page="files"),
        )

    @router.get("/portal/files/browse/{bucket_id}", response_class=HTMLResponse)
    async def portal_files_browse(request: Request, bucket_id: str, prefix: str = ""):
        """Browse files in a linked bucket."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        if not customer:
            if deps.settings.demo_mode and deps.customer_manager:
                customers = deps.customer_manager.list_customers()
                if customers:
                    customer = convert_customer_for_template(customers[0])
        if not customer:
            return RedirectResponse(url="/portal/login?error=No+customer+account+found", status_code=302)
        bucket = None
        items = []
        breadcrumbs = [{"name": "/", "prefix": ""}]  # Root breadcrumb
        current_prefix = prefix.rstrip("/") + "/" if prefix else ""
        # Calculate parent prefix - None at root, empty string for first level, path for deeper
        if not current_prefix:
            parent_prefix = None  # At root, no parent
        else:
            parent_parts = current_prefix.rstrip("/").split("/")[:-1]
            parent_prefix = "/".join(parent_parts) + "/" if parent_parts else ""
        if deps.linked_bucket_manager:
            bucket_obj = deps.linked_bucket_manager.get_bucket(bucket_id)
            if bucket_obj:
                LOGGER.debug(f"Bucket browse: bucket.customer_id={bucket_obj.customer_id}, user.customer_id={customer.customer_id}")
                if bucket_obj.customer_id != customer.customer_id:
                    LOGGER.warning(f"Access denied: bucket {bucket_id} belongs to {bucket_obj.customer_id}, not {customer.customer_id}")
                    return RedirectResponse(url="/portal/files/buckets?error=Access+denied+to+this+bucket", status_code=302)
                bucket = {
                    "bucket_id": bucket_obj.bucket_id,
                    "bucket_name": bucket_obj.bucket_name,
                    "display_name": bucket_obj.display_name or bucket_obj.bucket_name,
                    "read_only": bucket_obj.read_only,
                    "can_write": bucket_obj.can_write,
                    "can_list": bucket_obj.can_list,
                    "can_read": bucket_obj.can_read,
                }
                try:
                    response = _portal_s3_client.list_objects_v2(
                        Bucket=bucket_obj.bucket_name,
                        Prefix=current_prefix,
                        Delimiter="/",
                        MaxKeys=500,
                    )
                    for cp in response.get("CommonPrefixes", []):
                        folder_path = cp["Prefix"]
                        folder_name = folder_path.rstrip("/").split("/")[-1]
                        items.append({
                            "name": folder_name,
                            "is_folder": True,
                            "key": folder_path,
                            "size_bytes": None,
                            "last_modified": None,
                            "file_format": None,
                            "is_registered": False,
                        })
                    for obj in response.get("Contents", []):
                        if obj["Key"] == current_prefix:
                            continue
                        filename = obj["Key"].split("/")[-1]
                        if filename:
                            file_format = _detect_file_format(filename)
                            items.append({
                                "name": filename,
                                "is_folder": False,
                                "key": obj["Key"],
                                "size_bytes": obj.get("Size", 0),
                                "file_format": file_format,
                                "last_modified": obj.get("LastModified").isoformat()
                                if obj.get("LastModified")
                                else None,
                                "is_registered": False,
                            })
                except Exception as e:
                    LOGGER.warning(f"Failed to browse bucket {bucket_id}: {e}")
        if current_prefix:
            parts = current_prefix.rstrip("/").split("/")
            for i, part in enumerate(parts):
                breadcrumbs.append({"name": part, "prefix": "/".join(parts[: i + 1]) + "/"})
        return deps.templates.TemplateResponse(
            request,
            "files/browse.html",
            _get_template_context(request, deps, customer=customer, bucket=bucket, items=items, breadcrumbs=breadcrumbs,
                                  current_prefix=current_prefix, parent_prefix=parent_prefix, active_page="files"),
        )

    @router.get("/portal/files/register", response_class=HTMLResponse)
    async def portal_files_register(request: Request):
        """File registration page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        buckets = []
        if deps.linked_bucket_manager and customer:
            try:
                LOGGER.info(f"Loading buckets for customer: {customer.customer_id}")
                linked_buckets = deps.linked_bucket_manager.list_customer_buckets(customer.customer_id)
                LOGGER.info(f"Found {len(linked_buckets)} linked buckets for {customer.customer_id}")
                buckets = [{"bucket_id": b.bucket_id, "bucket_name": b.bucket_name, "display_name": b.display_name,
                            "is_validated": b.is_validated, "can_read": b.can_read, "can_write": b.can_write, "can_list": b.can_list}
                           for b in linked_buckets]
                LOGGER.info(f"Buckets for dropdown: {buckets}")
            except Exception as e:
                LOGGER.warning(f"Failed to load buckets: {e}")
        return deps.templates.TemplateResponse(
            request,
            "files/register.html",
            _get_template_context(request, deps, customer=customer, buckets=buckets, active_page="files"),
        )

    @router.post("/portal/files/register", response_model=PortalFileAutoRegisterResponse)
    async def portal_files_register_submit(request: Request, payload: PortalFileAutoRegisterRequest):
        """Register selected discovered files from a linked bucket."""
        user_email = request.session.get("user_email")
        LOGGER.debug(f"portal_files_register_submit: Session user_email: '{user_email}'")
        if not user_email:
            raise HTTPException(status_code=401, detail="Not authenticated")
        customer, customer_config = _get_customer_for_session(request, deps)
        if not customer:
            raise HTTPException(status_code=401, detail="No customer account found")
        customer_id = customer.customer_id
        if not deps.file_registry or not deps.linked_bucket_manager:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="File management not configured")
        bucket_name = None
        if payload.bucket_id:
            bucket_obj = deps.linked_bucket_manager.get_bucket(payload.bucket_id)
            if not bucket_obj:
                raise HTTPException(status_code=404, detail=f"Bucket ID {payload.bucket_id} not found")
            if bucket_obj.customer_id != customer_id:
                raise HTTPException(status_code=403, detail="Access denied to this bucket")
            bucket_name = bucket_obj.bucket_name
        elif payload.bucket_name:
            bucket_name = payload.bucket_name
        else:
            raise HTTPException(status_code=400, detail="bucket_id or bucket_name required")

        # Discover files first
        from daylib.file_registry import BucketFileDiscovery
        discovery = BucketFileDiscovery(region=deps.settings.get_effective_region())
        formats = payload.file_formats or ["fastq", "bam", "vcf", "cram"]
        discovered_files = discovery.discover_files(
            bucket_name=bucket_name,
            prefix=payload.prefix,
            file_formats=formats,
            max_files=payload.max_files,
        )
        LOGGER.info(f"Discovered {len(discovered_files)} files for auto-registration")

        # Filter to selected keys if provided
        if payload.selected_keys:
            selected_set = set(payload.selected_keys)
            LOGGER.debug(f"Selected keys from request ({len(selected_set)}): {list(selected_set)[:5]}...")
            discovered_keys = {f.key for f in discovered_files}
            LOGGER.debug(f"Discovered keys ({len(discovered_keys)}): {list(discovered_keys)[:5]}...")
            matching_keys = selected_set & discovered_keys
            LOGGER.debug(f"Matching keys ({len(matching_keys)}): {list(matching_keys)[:5]}...")
            discovered_files = [f for f in discovered_files if f.key in selected_set]
            LOGGER.info(f"Filtered to {len(discovered_files)} selected files (requested {len(payload.selected_keys)})")

        # Check registration status
        discovered_files = discovery.check_registration_status(
            discovered_files=discovered_files,
            registry=deps.file_registry,
            customer_id=customer_id,
        )

        # Auto-register unregistered files
        registered, skipped, errors = discovery.auto_register_files(
            discovered_files=discovered_files,
            registry=deps.file_registry,
            customer_id=customer_id,
            biosample_id=payload.biosample_id,
            subject_id=payload.subject_id,
            sequencing_platform=payload.sequencing_platform,
        )
        LOGGER.info(f"Auto-registration complete: {registered} registered, {skipped} skipped, {len(errors)} errors")

        return PortalFileAutoRegisterResponse(registered_count=registered, skipped_count=skipped, errors=errors)

    @router.get("/portal/files/upload", response_class=HTMLResponse)
    async def portal_files_upload(request: Request):
        """File upload page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        buckets = []
        if deps.linked_bucket_manager and customer:
            try:
                linked_buckets = deps.linked_bucket_manager.list_customer_buckets(customer.customer_id)
                buckets = [{"bucket_id": b.bucket_id, "bucket_name": b.bucket_name, "display_name": b.display_name,
                            "is_validated": b.is_validated, "can_read": b.can_read, "can_write": b.can_write}
                           for b in linked_buckets]
            except Exception as e:
                LOGGER.warning(f"Failed to load buckets: {e}")
        return deps.templates.TemplateResponse(
            request,
            "files/upload.html",
            _get_template_context(request, deps, customer=customer, buckets=buckets, active_page="files"),
        )

    @router.post("/portal/files/upload")
    async def portal_files_upload_submit(
        request: Request,
        bucket_id: str = Form(...),
        prefix: str = Form(""),
        auto_register: bool = Form(True),
        file: UploadFile = File(...),
    ):
        """Handle file upload to S3 bucket."""
        user_email = request.session.get("user_email")
        customer_id = request.session.get("customer_id")
        if not user_email or not customer_id:
            raise HTTPException(status_code=401, detail="Not authenticated")
        if not deps.linked_bucket_manager:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="File management not configured")
        LOGGER.info(f"Upload request from {user_email}: {file.filename} to bucket {bucket_id}")
        bucket_obj = deps.linked_bucket_manager.get_bucket(bucket_id)
        if not bucket_obj:
            raise HTTPException(status_code=404, detail="Bucket not found")
        if bucket_obj.customer_id != customer_id:
            raise HTTPException(status_code=403, detail="Access denied to this bucket")
        if not bucket_obj.can_write:
            raise HTTPException(status_code=403, detail="Write access not enabled for this bucket")
        try:
            filename = file.filename
            if not filename:
                raise HTTPException(status_code=400, detail="Missing filename")

            normalized_prefix = prefix.strip("/")
            s3_key = f"{normalized_prefix}/{filename}" if normalized_prefix else filename
            # Use region-aware S3 client to avoid 403s when bucket is in a different region.
            _portal_s3_client.upload_fileobj(file.file, bucket_obj.bucket_name, s3_key)
            LOGGER.info(f"Uploaded {file.filename} to s3://{bucket_obj.bucket_name}/{s3_key}")
            response_payload: Dict[str, Any] = {
                "success": True,
                "bucket": bucket_obj.bucket_name,
                "key": s3_key,
                "filename": file.filename,
            }

            if auto_register and deps.file_registry:
                s3_uri = f"s3://{bucket_obj.bucket_name}/{s3_key}"
                content_length = 0
                etag: Optional[str] = None
                try:
                    head_obj = _portal_s3_client.head_object(bucket_obj.bucket_name, s3_key)
                    content_length = int(head_obj.get("ContentLength", 0) or 0)
                    raw_etag = head_obj.get("ETag")
                    if isinstance(raw_etag, str):
                        etag = raw_etag.strip('"')
                except Exception as head_err:
                    LOGGER.warning(
                        "Failed to fetch object metadata after upload for registration: bucket=%s key=%s error=%s",
                        sanitize_for_log(bucket_obj.bucket_name),
                        sanitize_for_log(s3_key),
                        str(head_err),
                    )

                read_number = 2 if any(token in filename for token in ("_R2", "_2.fastq", "_2.fq")) else 1
                registration = _FileRegistration(
                    file_id="",
                    customer_id=customer_id,
                    file_metadata=_FileMetadata(
                        file_id="",
                        s3_uri=s3_uri,
                        file_size_bytes=content_length,
                        md5_checksum=etag,
                        file_format=_detect_file_format(s3_uri),
                    ),
                    sequencing_metadata=_SequencingMetadata(platform="UNKNOWN", vendor="UNKNOWN"),
                    biosample_metadata=_BiosampleMetadata(
                        biosample_id="unassigned-biosample",
                        subject_id="unassigned-subject",
                        sample_type="unknown",
                    ),
                    read_number=read_number,
                    tags=["source:portal_upload"],
                )
                registered = deps.file_registry.register_file(registration)
                if not registered:
                    LOGGER.error(
                        "Portal upload registration returned False: customer_id=%s file_id=%s s3_uri=%s",
                        sanitize_for_log(customer_id),
                        sanitize_for_log(registration.file_id or ""),
                        sanitize_for_log(s3_uri),
                    )
                    raise HTTPException(
                        status_code=500,
                        detail="Upload succeeded, but file registration failed. Use auto-register from linked buckets to recover.",
                    )
                response_payload["registered"] = True
                response_payload["file_id"] = registration.file_id
            elif auto_register and not deps.file_registry:
                LOGGER.warning(
                    "Portal upload auto-register requested but file registry is unavailable for customer_id=%s",
                    sanitize_for_log(customer_id),
                )
                response_payload["registered"] = False
                response_payload["warning"] = "File uploaded but registry is unavailable; file list may not update."
            else:
                response_payload["registered"] = False

            return response_payload
        except HTTPException:
            raise
        except ClientError as e:
            error = e.response.get("Error", {}) if isinstance(e.response, dict) else {}
            error_code = str(error.get("Code", ""))
            # IAM / bucket-policy failure modes should be surfaced as 403 (not 500).
            if error_code in {"AccessDenied", "AllAccessDisabled"}:
                LOGGER.warning(
                    "S3 access denied during portal upload: bucket=%s key=%s code=%s",
                    sanitize_for_log(bucket_obj.bucket_name),
                    sanitize_for_log(s3_key),
                    error_code,
                )
                raise HTTPException(
                    status_code=403,
                    detail=(
                        f"S3 access denied ({error_code}). "
                        "Verify IAM permissions and bucket policy."
                    ),
                )
            LOGGER.error(
                "S3 ClientError during portal upload: bucket=%s key=%s code=%s error=%s",
                sanitize_for_log(bucket_obj.bucket_name),
                sanitize_for_log(s3_key),
                error_code,
                str(e),
            )
            raise HTTPException(status_code=500, detail="Upload failed due to an S3 error")
        except Exception as e:
            LOGGER.error(f"Upload failed: {e}")
            raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

    @router.get("/portal/files/filesets", response_class=HTMLResponse)
    async def portal_files_filesets(request: Request):
        """File sets management page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        filesets = []
        if deps.file_registry and customer:
            try:
                fileset_objs = deps.file_registry.list_customer_filesets(customer.customer_id)
                filesets = [
                    {"fileset_id": fs.fileset_id, "customer_id": fs.customer_id, "name": fs.name, "description": fs.description,
                     "file_count": len(fs.file_ids), "created_at": fs.created_at.isoformat() if fs.created_at else None}
                    for fs in fileset_objs
                ]
            except Exception as e:
                LOGGER.warning(f"Failed to load filesets: {e}")
        return deps.templates.TemplateResponse(
            request,
            "files/filesets.html",
            _get_template_context(request, deps, customer=customer, filesets=filesets, active_page="files"),
        )

    @router.get("/portal/files/filesets/{fileset_id}", response_class=HTMLResponse)
    async def portal_files_fileset_detail(request: Request, fileset_id: str):
        """File set detail page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        fileset = None
        files = []
        if deps.file_registry:
            try:
                fileset = deps.file_registry.get_fileset(fileset_id)
                if fileset:
                    files = deps.file_registry.get_fileset_files(fileset_id)
            except Exception as e:
                LOGGER.warning(f"Failed to load fileset: {e}")
        if not fileset:
            raise HTTPException(status_code=404, detail="File set not found")
        unique_subjects = len(set(f.biosample_metadata.subject_id for f in files if f.biosample_metadata and f.biosample_metadata.subject_id))
        return deps.templates.TemplateResponse(
            request,
            "files/fileset_detail.html",
            _get_template_context(request, deps, customer=customer, fileset=fileset, files=files, unique_subjects=unique_subjects, active_page="files"),
        )

    @router.get("/portal/files/{file_id}", response_class=HTMLResponse)
    async def portal_files_detail(request: Request, file_id: str):
        """File detail page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        file = None
        workset_history = []
        if deps.file_registry:
            try:
                file = deps.file_registry.get_file(file_id)
                if file:
                    workset_history = deps.file_registry.get_file_workset_history(file_id)
            except Exception as e:
                LOGGER.warning(f"Failed to load file: {e}")
        if not file:
            raise HTTPException(status_code=404, detail="File not found")
        return deps.templates.TemplateResponse(
            request,
            "files/detail.html",
            _get_template_context(request, deps, customer=customer, file=file, workset_history=workset_history, active_page="files"),
        )

    @router.get("/portal/files/{file_id}/edit", response_class=HTMLResponse)
    async def portal_files_edit(request: Request, file_id: str):
        """File edit page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        file = None
        if deps.file_registry:
            try:
                file = deps.file_registry.get_file(file_id)
            except Exception as e:
                LOGGER.warning(f"Failed to load file for edit: {e}")
        if not file:
            raise HTTPException(status_code=404, detail="File not found")
        return deps.templates.TemplateResponse(
            request,
            "files/edit_file.html",
            _get_template_context(request, deps, customer=customer, file=file, active_page="files"),
        )

    @router.get("/portal/files/browser", response_class=HTMLResponse)
    async def portal_files_browser(request: Request, prefix: str = ""):
        """S3 file browser (legacy, uses customer's primary bucket)."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer = None
        folders: List[Dict[str, Any]] = []
        files: List[Dict[str, Any]] = []
        storage: Dict[str, Any] = {"used_gb": 0, "max_gb": 500, "files": files, "folders": folders}
        if deps.customer_manager:
            customers = deps.customer_manager.list_customers()
            if customers:
                customer_raw = customers[0]
                customer = convert_customer_for_template(customer_raw)
                storage["max_gb"] = customer.max_storage_gb

                try:
                    response = _portal_s3_client.list_objects_v2(
                        Bucket=customer.s3_bucket,
                        Prefix=prefix,
                        Delimiter="/",
                    )
                    for cp in response.get("CommonPrefixes", []):
                        folder_path = cp["Prefix"]
                        folder_name = folder_path.rstrip("/").split("/")[-1]
                        folders.append({"name": folder_name, "path": folder_path})
                    for obj in response.get("Contents", []):
                        if obj["Key"] == prefix:
                            continue
                        filename = obj["Key"].split("/")[-1]
                        if filename:
                            files.append({
                                "name": filename,
                                "key": obj["Key"],
                                "size": obj.get("Size", 0),
                                "size_formatted": format_file_size(obj.get("Size", 0)),
                                "last_modified": obj.get("LastModified").isoformat()
                                if obj.get("LastModified")
                                else None,
                            })
                except Exception as e:
                    LOGGER.warning(f"Failed to browse S3: {e}")
        return deps.templates.TemplateResponse(
            request,
            "files/browser.html",
            _get_template_context(request, deps, customer=customer, storage=storage, prefix=prefix, active_page="files"),
        )


    # ========== Usage Routes ==========

    @router.get("/portal/usage", response_class=HTMLResponse)
    async def portal_usage(request: Request):
        """Usage and billing page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect

        customer, _customer_config = _get_customer_for_session(request, deps)
        customer_id = request.session.get("customer_id")

        usage: Dict[str, Any] = {
            "total_cost": 0,
            "compute_cost_usd": 0,
            "storage_cost_usd": 0,
            "transfer_cost_usd": 0,
            "cost_change": 0,
            "vcpu_hours": 0,
            "memory_gb_hours": 0,
            "storage_gb": 0,
            "active_worksets": 0,
        }
        usage_details: List[Dict[str, Any]] = []
        workset_storage_breakdown: List[Dict[str, Any]] = []

        if deps.customer_manager and customer_id:
            customer_usage = deps.customer_manager.get_customer_usage(customer_id)
            if customer_usage:
                usage.update(customer_usage)

        # Generate usage details from completed worksets for *this customer*
        if deps.state_db and customer_id:
            try:
                from daylib.billing import BillingCalculator, calculate_customer_cost_breakdown

                breakdown = calculate_customer_cost_breakdown(deps.state_db, customer_id, limit=500)
                usage["compute_cost_usd"] = breakdown["compute_cost_usd"]
                usage["storage_cost_usd"] = breakdown["storage_cost_usd"]
                usage["transfer_cost_usd"] = breakdown["transfer_cost_usd"]
                usage["total_cost"] = breakdown["total"]

                # Transfer breakdown (3-way)
                usage["transfer_intra_region_cost_usd"] = breakdown["transfer_intra_region_cost_usd"]
                usage["transfer_cross_region_cost_usd"] = breakdown["transfer_cross_region_cost_usd"]
                usage["transfer_internet_cost_usd"] = breakdown["transfer_internet_cost_usd"]
                usage["transfer_intra_region_gb"] = breakdown["transfer_intra_region_gb"]
                usage["transfer_cross_region_gb"] = breakdown["transfer_cross_region_gb"]
                usage["transfer_internet_gb"] = breakdown["transfer_internet_gb"]

                # Rate fields (backwards-compatible aggregate key retained for template fallbacks)
                usage["transfer_rate_per_gb"] = breakdown["rates"]["data_egress_per_gb"]
                usage["transfer_intra_region_rate_per_gb"] = breakdown["rates"][
                    "data_transfer_intra_region_per_gb"
                ]
                usage["transfer_cross_region_rate_per_gb"] = breakdown["rates"][
                    "data_transfer_cross_region_per_gb"
                ]
                usage["transfer_internet_rate_per_gb"] = breakdown["rates"]["data_egress_per_gb"]
                usage["workset_storage_bytes"] = breakdown["total_storage_bytes"]
                usage["workset_storage_gb"] = breakdown["storage_gb"]
                usage["storage_gb"] = breakdown["storage_gb"]
                usage["workset_storage_human"] = _format_bytes(breakdown["total_storage_bytes"])

                calculator = BillingCalculator(state_db=deps.state_db)
                completed_worksets = deps.state_db.list_worksets_by_customer(
                    customer_id,
                    state=WorksetState.COMPLETE,
                    limit=100,
                )

                for ws in completed_worksets:
                    item = calculator.calculate_workset_billing(ws)
                    completed_at = item.completed_at or ws.get("updated_at", ws.get("created_at", ""))
                    completed_date = completed_at[:10] if completed_at else "-"

                    if item.compute_cost_usd > 0:
                        usage_details.append(
                            {
                                "date": completed_date,
                                "type": "Compute",
                                "workset_id": item.workset_id,
                                "quantity": item.sample_count or 1,
                                "unit": "samples",
                                "cost": item.compute_cost_usd,
                                "is_actual": item.has_actual_compute_cost,
                            }
                        )

                    if item.storage_bytes > 0:
                        workset_storage_breakdown.append(
                            {
                                "workset_id": item.workset_id,
                                "storage_bytes": item.storage_bytes,
                                "storage_human": _format_bytes(item.storage_bytes),
                                "storage_gb": round(item.storage_gb, 2),
                                "completed_at": completed_date,
                            }
                        )

                usage_details.sort(key=lambda x: x["date"], reverse=True)
                workset_storage_breakdown.sort(key=lambda x: x["storage_bytes"], reverse=True)

                # Append summary rows for storage/transfer so the table aligns with the cards.
                if breakdown["storage_gb"] > 0:
                    usage_details.append(
                        {
                            "date": "-",
                            "type": "Storage",
                            "workset_id": None,
                            "workset_label": "All worksets",
                            "quantity": breakdown["storage_gb"],
                            "unit": "GB/month",
                            "cost": breakdown["storage_cost_usd"],
                            "is_actual": True,
                        }
                    )

                if (
                    breakdown.get("transfer_intra_region_gb", 0) > 0
                    or breakdown.get("transfer_cross_region_gb", 0) > 0
                    or breakdown.get("transfer_internet_gb", 0) > 0
                ):
                    usage_details.extend(
                        [
                            {
                                "date": "-",
                                "type": "Transfer",
                                "workset_id": None,
                                "workset_label": "All worksets (Transfer: Intra-region)",
                                "quantity": breakdown.get("transfer_intra_region_gb", 0),
                                "unit": "GB",
                                "cost": breakdown.get("transfer_intra_region_cost_usd", 0),
                                "is_actual": False,
                            },
                            {
                                "date": "-",
                                "type": "Transfer",
                                "workset_id": None,
                                "workset_label": "All worksets (Transfer: Cross-region)",
                                "quantity": breakdown.get("transfer_cross_region_gb", 0),
                                "unit": "GB",
                                "cost": breakdown.get("transfer_cross_region_cost_usd", 0),
                                "is_actual": False,
                            },
                            {
                                "date": "-",
                                "type": "Transfer",
                                "workset_id": None,
                                "workset_label": "All worksets (Internet egress)",
                                "quantity": breakdown.get("transfer_internet_gb", 0),
                                "unit": "GB",
                                "cost": breakdown.get("transfer_internet_cost_usd", 0),
                                "is_actual": False,
                            },
                        ]
                    )
            except Exception as e:
                LOGGER.warning(f"Failed to load usage details: {e}")

        return deps.templates.TemplateResponse(
            request,
            "usage.html",
            _get_template_context(
                request,
                deps,
                customer=customer,
                usage=usage,
                usage_details=usage_details,
                workset_storage=workset_storage_breakdown,
                active_page="usage",
            ),
        )

    @router.get("/portal/usage/export")
    async def portal_usage_export(request: Request):
        """Export usage report as CSV for the currently-authenticated customer."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect

        if not deps.state_db:
            raise HTTPException(status_code=503, detail="State DB not configured")

        customer_id = request.session.get("customer_id")
        if not customer_id:
            raise HTTPException(status_code=400, detail="Missing customer_id in session")

        from daylib.billing import BillingCalculator, calculate_customer_cost_breakdown

        breakdown = calculate_customer_cost_breakdown(deps.state_db, customer_id, limit=500)
        calculator = BillingCalculator(state_db=deps.state_db)

        worksets = deps.state_db.list_worksets_by_customer(
            customer_id,
            state=WorksetState.COMPLETE,
            limit=500,
        )

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(
            [
                "date",
                "workset_id",
                "sample_count",
                "compute_cost_usd",
                "storage_gb",
                "storage_cost_usd",
                "transfer_gb",
                "transfer_cost_usd",
                "intra_region_transfer_gb",
                "intra_region_transfer_cost_usd",
                "cross_region_transfer_gb",
                "cross_region_transfer_cost_usd",
                "internet_egress_gb",
                "internet_egress_cost_usd",
                "total_cost_usd",
                "has_actual_compute_cost",
            ]
        )

        transfer_gb_total = 0.0
        transfer_intra_gb_total = 0.0
        transfer_cross_gb_total = 0.0
        internet_egress_gb_total = 0.0
        for ws in worksets:
            item = calculator.calculate_workset_billing(ws)
            completed_at = item.completed_at or ws.get("updated_at", ws.get("created_at", ""))
            completed_date = completed_at[:10] if completed_at else "-"
            transfer_gb_total += float(item.transfer_gb or 0)
            transfer_intra_gb_total += float(item.transfer_intra_region_gb or 0)
            transfer_cross_gb_total += float(item.transfer_cross_region_gb or 0)
            internet_egress_gb_total += float(item.transfer_internet_gb or 0)
            writer.writerow(
                [
                    completed_date,
                    item.workset_id,
                    item.sample_count,
                    round(item.compute_cost_usd, 2),
                    round(item.storage_gb, 2),
                    round(item.storage_cost_usd, 4),
                    round(item.transfer_gb, 2),
                    round(item.transfer_cost_usd, 4),
                    round(item.transfer_intra_region_gb, 2),
                    round(item.transfer_intra_region_cost_usd, 4),
                    round(item.transfer_cross_region_gb, 2),
                    round(item.transfer_cross_region_cost_usd, 4),
                    round(item.transfer_internet_gb, 2),
                    round(item.transfer_internet_cost_usd, 4),
                    round(item.total_cost_usd, 2),
                    bool(item.has_actual_compute_cost),
                ]
            )

        writer.writerow([])
        writer.writerow(
            [
                "TOTAL",
                "",
                "",
                breakdown["compute_cost_usd"],
                breakdown["storage_gb"],
                breakdown["storage_cost_usd"],
                round(transfer_gb_total, 2),
                breakdown["transfer_cost_usd"],
                round(transfer_intra_gb_total, 2),
                breakdown.get("transfer_intra_region_cost_usd", 0.0),
                round(transfer_cross_gb_total, 2),
                breakdown.get("transfer_cross_region_cost_usd", 0.0),
                round(internet_egress_gb_total, 2),
                breakdown.get("transfer_internet_cost_usd", 0.0),
                breakdown["total"],
                "",
            ]
        )

        csv_text = output.getvalue()
        filename = (
            f"ursa-usage-report-{customer_id}-{datetime.now(timezone.utc).strftime('%Y-%m-%d')}.csv"
        )
        headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
        return StreamingResponse(iter([csv_text]), media_type="text/csv", headers=headers)

    # ========== Biospecimen Routes ==========

    @router.get("/portal/subjects", response_class=RedirectResponse)
    async def portal_subjects(request: Request):
        """Dedicated subjects entrypoint.

        For now this aliases the biospecimen subjects page.
        """
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        return RedirectResponse(url="/portal/biospecimen/subjects", status_code=302)

    @router.get("/portal/biospecimen", response_class=HTMLResponse)
    @router.get("/portal/biospecimen/subjects", response_class=HTMLResponse)
    async def portal_biospecimen_subjects(
        request: Request,
        q: Optional[str] = None,
        subject_id: Optional[str] = None,
    ):
        """Subjects management page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        customer_id = customer.customer_id if customer else request.session.get("customer_id", "default-customer")
        subjects: List[Dict[str, Any]] = []
        stats = {"subjects": 0, "biosamples": 0, "libraries": 0}

        # Load subjects from biospecimen registry if available
        if deps.biospecimen_registry:
            try:
                subject_objs = deps.biospecimen_registry.list_subjects(customer_id, limit=500)
                for subj in subject_objs:
                    subj_dict = {
                        "subject_id": subj.subject_id,
                        "identifier": subj.identifier,
                        "display_name": subj.display_name,
                        "sex": subj.sex,
                        "cohort": subj.cohort,
                        "created_at": subj.created_at,
                        "biosample_count": 0,
                    }
                    # Count biosamples for this subject
                    try:
                        biosamples = deps.biospecimen_registry.list_biosamples_for_subject(subj.subject_id)
                        subj_dict["biosample_count"] = len(biosamples)
                    except Exception:
                        pass
                    subjects.append(subj_dict)
                stats["subjects"] = len(subjects)
                # Get total biosamples and libraries counts
                try:
                    all_biosamples = deps.biospecimen_registry.list_biosamples(customer_id, limit=1000)
                    stats["biosamples"] = len(all_biosamples)
                except Exception:
                    pass
                try:
                    all_libraries = deps.biospecimen_registry.list_libraries(customer_id, limit=1000)
                    stats["libraries"] = len(all_libraries)
                except Exception:
                    pass
            except Exception as e:
                LOGGER.warning(f"Failed to load subjects from biospecimen registry: {e}")

        query_text = str(q or "").strip().lower()
        subject_id_filter = str(subject_id or "").strip().lower()

        if subject_id_filter:
            subjects = [
                subj
                for subj in subjects
                if subject_id_filter in str(subj.get("subject_id", "")).lower()
                or subject_id_filter in str(subj.get("identifier", "")).lower()
            ]
        if query_text:
            subjects = [
                subj
                for subj in subjects
                if query_text in str(subj.get("subject_id", "")).lower()
                or query_text in str(subj.get("identifier", "")).lower()
                or query_text in str(subj.get("display_name", "")).lower()
                or query_text in str(subj.get("cohort", "")).lower()
                or query_text in str(subj.get("sex", "")).lower()
            ]

        return deps.templates.TemplateResponse(
            request,
            "biospecimen/subjects.html",
            _get_template_context(
                request,
                deps,
                customer=customer,
                subjects=subjects,
                stats=stats,
                subject_query=q or "",
                subject_id_filter=subject_id or "",
                active_page="biospecimen",
            ),
        )

    # ========== Account Routes ==========

    @router.get("/portal/account", response_class=HTMLResponse)
    async def portal_account(request: Request):
        """Account settings page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        # Use session-based customer lookup, not first customer in DB
        customer, _ = _get_customer_for_session(request, deps)
        app_settings = deps.settings

        # Debug info for troubleshooting session/customer mismatches
        session_info = {
            "session_user_email": request.session.get("user_email"),
            "session_customer_id": request.session.get("customer_id"),
            "session_logged_in": request.session.get("logged_in"),
        }
        db_customer_id = customer.customer_id if customer else None

        env_vars = {
            "AWS_PROFILE": app_settings.aws_profile,
            "AWS_REGION": app_settings.get_effective_region(),
            "AWS_ACCESS_KEY_ID": "***" if os.getenv("AWS_ACCESS_KEY_ID") else None,
            "AWS_SECRET_ACCESS_KEY": "***" if os.getenv("AWS_SECRET_ACCESS_KEY") else None,
            "AWS_ACCOUNT_ID": app_settings.aws_account_id,
            "TAPDB_STRICT_NAMESPACE": os.getenv("TAPDB_STRICT_NAMESPACE"),
            "TAPDB_CLIENT_ID": os.getenv("TAPDB_CLIENT_ID"),
            "TAPDB_DATABASE_NAME": os.getenv("TAPDB_DATABASE_NAME"),
            "TAPDB_ENV": os.getenv("TAPDB_ENV"),
            "TAPDB_CONFIG_PATH": os.getenv("TAPDB_CONFIG_PATH"),
            "COGNITO_USER_POOL_ID": app_settings.cognito_user_pool_id,
            "COGNITO_APP_CLIENT_ID": app_settings.cognito_app_client_id,
            "COGNITO_APP_CLIENT_SECRET": "***" if app_settings.cognito_app_client_secret else None,
            "COGNITO_DOMAIN": app_settings.cognito_domain,
            "DAYLILY_PRIMARY_REGION": os.getenv("DAYLILY_PRIMARY_REGION"),
            "DAYLILY_MULTI_REGION": os.getenv("DAYLILY_MULTI_REGION"),
            "APPTAINER_HOME": os.getenv("APPTAINER_HOME"),
            "DAY_BIOME": os.getenv("DAY_BIOME"),
            "DAY_ROOT": os.getenv("DAY_ROOT"),
        }
        return deps.templates.TemplateResponse(
            request,
            "account.html",
            _get_template_context(request, deps, customer=customer, active_page="account", env_vars=env_vars, session_info=session_info, db_customer_id=db_customer_id),
        )

    # ========== Static Pages ==========

    @router.get("/portal/docs", response_class=HTMLResponse)
    async def portal_docs(request: Request):
        """Documentation page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        return deps.templates.TemplateResponse(
            request,
            "docs.html",
            _get_template_context(request, deps, customer=customer, active_page="docs"),
        )

    @router.get("/portal/support", response_class=HTMLResponse)
    async def portal_support(request: Request):
        """Support/Contact page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)
        return deps.templates.TemplateResponse(
            request,
            "support.html",
            _get_template_context(request, deps, customer=customer, active_page="support"),
        )

    @router.get("/portal/info", response_class=HTMLResponse)
    async def portal_info(request: Request):
        """Dependency and persistence information page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect

        customer, _ = _get_customer_for_session(request, deps)
        app_settings = deps.settings

        cognito_installed = _is_module_available("daylily_cognito")
        cognito_version = _get_distribution_version("daylily-cognito")
        tapdb_installed = _is_module_available("daylily_tapdb")
        tapdb_dist_version = _get_distribution_version("daylily-tapdb")
        tapdb_module_version = None
        try:
            import daylily_tapdb  # type: ignore

            tapdb_module_version = getattr(daylily_tapdb, "__version__", None)
        except Exception:
            tapdb_module_version = None

        tapdb_env_vars = sorted(key for key in os.environ.keys() if key.startswith("TAPDB_"))
        tapdb_cfg: dict | None = None
        tapdb_cfg_error: str | None = None
        try:
            from daylily_tapdb.cli.db_config import get_db_config_for_env  # type: ignore

            env_name = (os.getenv("TAPDB_ENV") or "").strip()
            if env_name:
                tapdb_cfg = get_db_config_for_env(env_name)
        except Exception as exc:
            tapdb_cfg_error = f"{type(exc).__name__}: {exc}"

        cognito_rows = [
            {"key": "Distribution", "value": "daylily-cognito"},
            {"key": "Module", "value": "daylily_cognito"},
            {"key": "Installed", "value": "Yes" if cognito_installed else "No"},
            {"key": "Version", "value": cognito_version or "Not installed"},
            {"key": "Auth enabled in Ursa", "value": "Yes" if deps.enable_auth else "No"},
            {
                "key": "Auth backend initialized",
                "value": "Yes" if bool(deps.enable_auth and deps.cognito_auth) else "No",
            },
            {"key": "Cognito region", "value": os.getenv("COGNITO_REGION") or "Not set"},
            {"key": "User pool ID", "value": app_settings.cognito_user_pool_id or "Not set"},
            {"key": "App client ID", "value": app_settings.cognito_app_client_id or "Not set"},
            {"key": "Hosted UI domain", "value": _get_effective_cognito_domain(deps) or "Not set"},
            {"key": "Callback URL", "value": _get_effective_callback_url(request)},
            {"key": "Logout URL", "value": _get_effective_logout_url(request)},
        ]

        tapdb_rows = [
            {"key": "Distribution", "value": "daylily-tapdb"},
            {"key": "Module", "value": "daylily_tapdb"},
            {"key": "Installed", "value": "Yes" if tapdb_installed else "No"},
            {"key": "Dist version", "value": tapdb_dist_version or "Not installed"},
            {"key": "Module version", "value": tapdb_module_version or "Unknown"},
            {"key": "Integrated in current runtime", "value": "Yes"},
            {
                "key": "Namespace",
                "value": (
                    f"{os.getenv('TAPDB_CLIENT_ID')}/{os.getenv('TAPDB_DATABASE_NAME')}"
                    if os.getenv("TAPDB_CLIENT_ID") and os.getenv("TAPDB_DATABASE_NAME")
                    else "Not set"
                ),
            },
            {"key": "TAPDB_ENV", "value": os.getenv("TAPDB_ENV") or "Not set"},
            {
                "key": "Detected TAPDB_* env vars",
                "value": ", ".join(tapdb_env_vars) if tapdb_env_vars else "None",
            },
        ]

        persistence_rows = [{"key": "Backend", "value": "TapDB graph (Postgres)"}]
        if tapdb_cfg:
            persistence_rows.extend(
                [
                    {"key": "Config path", "value": str(tapdb_cfg.get("config_path") or "") or "Unknown"},
                    {"key": "Engine type", "value": str(tapdb_cfg.get("engine_type") or "") or "Unknown"},
                    {"key": "Host", "value": str(tapdb_cfg.get("host") or "") or "Unknown"},
                    {"key": "Port", "value": str(tapdb_cfg.get("port") or "") or "Unknown"},
                    {"key": "Database", "value": str(tapdb_cfg.get("database") or "") or "Unknown"},
                ]
            )
        elif tapdb_cfg_error:
            persistence_rows.append({"key": "Config error", "value": tapdb_cfg_error})

        return deps.templates.TemplateResponse(
            request,
            "info.html",
            _get_template_context(
                request,
                deps,
                customer=customer,
                active_page="info",
                cognito_rows=cognito_rows,
                tapdb_rows=tapdb_rows,
                persistence_rows=persistence_rows,
                generated_at=datetime.now(timezone.utc).isoformat(),
            ),
        )

    # ========== Feature Requests Routes ==========

    @router.get("/portal/feature-requests", response_class=HTMLResponse)
    async def portal_feature_requests(request: Request):
        """Feature requests page."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)

        # Load existing requests from JSON file
        requests = []
        requests_file = Path.home() / ".ursa" / "feature_requests.json"
        if requests_file.exists():
            try:
                import json
                with open(requests_file) as f:
                    requests = json.load(f)
                # Sort by date descending
                requests.sort(key=lambda x: x.get("submitted_at", ""), reverse=True)
            except Exception as e:
                LOGGER.warning(f"Failed to load feature requests: {e}")

        return deps.templates.TemplateResponse(
            request,
            "feature_requests.html",
            _get_template_context(request, deps, customer=customer, requests=requests, active_page="feature_requests"),
        )

    @router.post("/portal/feature-requests")
    async def portal_feature_requests_submit(request: Request):
        """Handle feature request submission."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return JSONResponse(status_code=401, content={"detail": "Not authenticated"})

        try:
            import json
            from datetime import datetime, timezone

            data = await request.json()
            user_email = request.session.get("user_email", "anonymous")
            customer_id = request.session.get("customer_id", "unknown")

            feature_request = {
                "id": f"fr-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}",
                "title": data.get("title", "").strip(),
                "category": data.get("category", "other"),
                "description": data.get("description", "").strip(),
                "priority": data.get("priority", "nice-to-have"),
                "submitted_by": user_email,
                "customer_id": customer_id,
                "submitted_at": datetime.now(timezone.utc).isoformat(),
                "status": "submitted",
            }

            # Save to JSON file
            requests_file = Path.home() / ".ursa" / "feature_requests.json"
            requests_file.parent.mkdir(parents=True, exist_ok=True)

            requests = []
            if requests_file.exists():
                with open(requests_file) as f:
                    requests = json.load(f)

            requests.append(feature_request)

            with open(requests_file, "w") as f:
                json.dump(requests, f, indent=2)

            LOGGER.info(f"Feature request submitted: {feature_request['id']} by {user_email}")
            return JSONResponse(content={"status": "ok", "id": feature_request["id"]})

        except Exception as e:
            LOGGER.error(f"Failed to save feature request: {e}")
            return JSONResponse(status_code=500, content={"detail": str(e)})

    # ========== Monitor Dashboard Route ==========

    @router.get("/portal/monitor", response_class=HTMLResponse)
    async def portal_monitor(request: Request):
        """Monitor dashboard - shows workset monitor daemon status and activity."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        _require_admin(request)
        customer, _ = _get_customer_for_session(request, deps)

        # Import monitor-related utilities
        import os
        import yaml as yaml_lib  # type: ignore[import-untyped]
        from datetime import datetime, timezone

        # Monitor paths (same as in daylib/cli/monitor.py)
        config_dir = Path.home() / ".ursa"
        log_dir = config_dir / "logs"
        pid_file = config_dir / "monitor.pid"

        # Check if monitor is running
        monitor_pid = None
        monitor_running = False
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
                os.kill(pid, 0)  # Check if process exists
                monitor_pid = pid
                monitor_running = True
            except (ValueError, ProcessLookupError, PermissionError):
                pass

        # Get latest log file
        latest_log_path = None
        log_files = sorted(log_dir.glob("monitor_*.log"), reverse=True) if log_dir.exists() else []
        if log_files:
            latest_log_path = log_files[0]

        # Calculate uptime if running (based on log file modification time)
        uptime_str = None
        start_time_str = None
        if monitor_running and latest_log_path and latest_log_path.exists():
            try:
                # Use log file creation time as proxy for start time
                log_stat = latest_log_path.stat()
                start_time = datetime.fromtimestamp(log_stat.st_ctime, tz=timezone.utc)
                start_time_str = start_time.strftime("%Y-%m-%d %H:%M:%S UTC")
                uptime_seconds = (datetime.now(timezone.utc) - start_time).total_seconds()
                hours = int(uptime_seconds // 3600)
                minutes = int((uptime_seconds % 3600) // 60)
                uptime_str = f"{hours}h {minutes}m" if hours > 0 else f"{minutes}m"
            except Exception:
                pass

        # Load monitor config
        monitor_config: Dict[str, Any] = {}
        config_path = None
        config_search_paths = [
            config_dir / "monitor-config.yaml",
            Path.cwd() / "config" / "workset-monitor-config.yaml",
            Path.cwd() / "config" / "daylily-workset-monitor.yaml",
        ]
        for p in config_search_paths:
            if p.exists():
                config_path = p
                break

        if config_path:
            try:
                with config_path.open("r", encoding="utf-8") as f:
                    monitor_config = yaml_lib.safe_load(f) or {}
            except Exception as e:
                LOGGER.warning(f"Failed to load monitor config: {e}")

        # Extract config values for display
        monitor_opts = monitor_config.get("monitor", {})
        cluster_opts = monitor_config.get("cluster", {})

        # Get max_concurrent_worksets from YAML config as default
        max_concurrent_from_config = monitor_opts.get("max_concurrent_worksets", 1)
        max_concurrent_runtime = max_concurrent_from_config

        # If monitor is running, try to extract actual runtime value from log
        # The monitor logs: "Poll interval: %ds, continuous: %s, max parallel: %d"
        # Note: With verbose boto logging, this message can appear 100+ lines into the log
        import re
        if latest_log_path and latest_log_path.exists():
            try:
                with latest_log_path.open("r", encoding="utf-8", errors="replace") as f:
                    # Read first ~200 lines to find startup message (boto debug logs can be verbose)
                    for i, line in enumerate(f):
                        if i > 200:
                            break
                        match = re.search(r"max parallel:\s*(\d+)", line, re.IGNORECASE)
                        if match:
                            max_concurrent_runtime = int(match.group(1))
                            LOGGER.debug(f"Found max parallel in log line {i}: {max_concurrent_runtime}")
                            break
            except Exception as e:
                LOGGER.warning(f"Failed to parse log file for max parallel: {e}")

        config_display = {
            "prefix": monitor_opts.get("prefix", "worksets/"),
            "poll_interval_seconds": monitor_opts.get("poll_interval_seconds", 60),
            "max_concurrent_worksets": max_concurrent_runtime,
            "archive_prefix": monitor_opts.get("archive_prefix", ""),
            "reuse_cluster_name": cluster_opts.get("reuse_cluster_name", ""),
            "config_path": str(config_path) if config_path else "Not found",
        }

        # Get workset statistics from TapDB
        stats = {
            "in_progress": 0,
            "ready": 0,
            "complete": 0,
            "error": 0,
            "total_processed": 0,
        }
        try:
            for ws_state in WorksetState:
                batch = deps.state_db.list_worksets_by_state(ws_state, limit=500)
                count = len(batch)
                if ws_state == WorksetState.IN_PROGRESS:
                    stats["in_progress"] = count
                elif ws_state == WorksetState.READY:
                    stats["ready"] = count
                elif ws_state == WorksetState.COMPLETE:
                    stats["complete"] = count
                    stats["total_processed"] += count
                elif ws_state == WorksetState.ERROR:
                    stats["error"] = count
                    stats["total_processed"] += count
        except Exception as e:
            LOGGER.warning(f"Failed to get workset stats: {e}")

        # Read recent log lines
        log_lines = []
        log_error = None
        if latest_log_path and latest_log_path.exists():
            try:
                with latest_log_path.open("r", encoding="utf-8", errors="replace") as f:
                    all_lines = f.readlines()
                    log_lines = all_lines[-100:]  # Last 100 lines
            except Exception as e:
                log_error = str(e)

        return deps.templates.TemplateResponse(
            request,
            "monitor/dashboard.html",
            _get_template_context(
                request, deps,
                customer=customer,
                monitor_running=monitor_running,
                monitor_pid=monitor_pid,
                uptime_str=uptime_str,
                start_time_str=start_time_str,
                config_display=config_display,
                stats=stats,
                log_lines=log_lines,
                log_error=log_error,
                latest_log_path=str(latest_log_path) if latest_log_path else None,
                log_files=[str(lf.name) for lf in log_files[:10]],
                active_page="monitor",
            ),
        )

    # ========== Admin Tools ==========

    @router.get("/portal/admin/users", response_class=HTMLResponse)
    async def portal_admin_users(
        request: Request,
        error: Optional[str] = None,
        success: Optional[str] = None,
        q: Optional[str] = None,
    ):
        """Admin: manage portal users (customers)."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        _require_admin(request)

        customer, _ = _get_customer_for_session(request, deps)
        customers = []
        if not deps.customer_manager:
            error = error or "Customer manager not configured"
        else:
            try:
                customers = deps.customer_manager.list_customers()
            except Exception as e:
                LOGGER.error("Failed to list customers: %s", e)
                error = error or "Failed to list customers"

        query_text = str(q or "").strip().lower()
        if query_text:
            customers = [
                customer_item
                for customer_item in customers
                if query_text in str(getattr(customer_item, "email", "")).lower()
                or query_text in str(getattr(customer_item, "customer_id", "")).lower()
                or query_text in str(getattr(customer_item, "customer_name", "")).lower()
            ]

        return deps.templates.TemplateResponse(
            request,
            "admin/users.html",
            _get_template_context(
                request,
                deps,
                customer=customer,
                customers=customers,
                error=error,
                success=success,
                user_query=q or "",
                active_page="admin_users",
            ),
        )

    @router.post("/portal/admin/users/add")
    async def portal_admin_users_add(
        request: Request,
        customer_name: str = Form(...),
        email: str = Form(...),
    ):
        """Admin: add a new user (creates customer config and optionally Cognito user)."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        _require_admin(request)

        if not deps.customer_manager:
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus("Customer manager not configured"),
                status_code=302,
            )

        domain_valid, domain_error = deps.settings.validate_email_domain(email)
        if not domain_valid:
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus(domain_error),
                status_code=302,
            )

        existing = deps.customer_manager.get_customer_by_email(email)
        if existing:
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus("User already exists"),
                status_code=302,
            )

        try:
            config = deps.customer_manager.onboard_customer(customer_name=customer_name, email=email)
        except Exception as e:
            LOGGER.error("Failed to onboard customer for %s: %s", sanitize_for_log(email), e)
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus("Failed to create user"),
                status_code=302,
            )

        cognito_note = None
        if deps.enable_auth and deps.cognito_auth:
            try:
                deps.cognito_auth.create_customer_user(
                    email=email,
                    customer_id=config.customer_id,
                    temporary_password=None,
                )
                cognito_note = "Cognito invite sent"
            except ValueError as e:
                LOGGER.warning("Cognito user creation skipped for %s: %s", sanitize_for_log(email), e)
                cognito_note = "Cognito user not created"
            except Exception as e:
                LOGGER.error("Failed to create Cognito user for %s: %s", sanitize_for_log(email), e)
                cognito_note = "Cognito user creation failed"

        msg = f"User created: {email} (Customer ID: {config.customer_id})"
        if cognito_note:
            msg = f"{msg}. {cognito_note}."

        return RedirectResponse(
            url="/portal/admin/users?success=" + quote_plus(msg),
            status_code=302,
        )


    @router.post("/portal/admin/users/set-admin")
    async def portal_admin_users_set_admin(
        request: Request,
        email: str = Form(...),
        is_admin: str = Form(...),
    ):
        """Admin: set or remove admin privileges for an email."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        _require_admin(request)

        if not deps.customer_manager:
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus("Customer manager not configured"),
                status_code=302,
            )

        is_admin_normalized = str(is_admin).strip().lower()
        desired_is_admin = is_admin_normalized in {"1", "true", "yes", "on"}

        try:
            target_customer = deps.customer_manager.get_customer_by_email(email)
            if target_customer is None:
                return RedirectResponse(
                    url="/portal/admin/users?error=" + quote_plus(f"User not found: {email}"),
                    status_code=302,
                )
            ok = deps.customer_manager.set_admin_status(
                customer_id=target_customer.customer_id,
                is_admin=desired_is_admin,
            )
        except Exception as e:
            LOGGER.error("Failed to set admin status for %s: %s", sanitize_for_log(email), e)
            ok = False

        if not ok:
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus("Failed to update admin status"),
                status_code=302,
            )

        # If the admin modifies themselves, update session so nav reflects change immediately.
        if request.session.get("user_email") == email:
            request.session["is_admin"] = desired_is_admin

        msg = f"Updated admin status for {email}: {'admin' if desired_is_admin else 'non-admin'}"
        return RedirectResponse(
            url="/portal/admin/users?success=" + quote_plus(msg),
            status_code=302,
        )


    @router.post("/portal/admin/users/set-password")
    async def portal_admin_users_set_password(
        request: Request,
        email: str = Form(...),
        password: str = Form(...),
        confirm_password: str = Form(...),
        force_change: Optional[str] = Form(None),
    ):
        """Admin: set/reset a user's password (Cognito)."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        _require_admin(request)

        if password != confirm_password:
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus("Passwords do not match"),
                status_code=302,
            )

        if not deps.cognito_auth:
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus("Cognito auth not configured"),
                status_code=302,
            )

        # HTML checkbox sends e.g. 'on' when checked; absent when unchecked.
        force_change_normalized = str(force_change).strip().lower() if force_change is not None else ""
        desired_permanent = force_change_normalized not in {"1", "true", "yes", "on"}

        try:
            deps.cognito_auth.set_user_password(email=email, password=password, permanent=desired_permanent)
        except HTTPException as e:
            # CognitoAuth may raise HTTPException (e.g., domain whitelist violations).
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus(str(e.detail)),
                status_code=302,
            )
        except ValueError as e:
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus(str(e)),
                status_code=302,
            )
        except Exception as e:
            LOGGER.error("Failed to set password for %s: %s", sanitize_for_log(email), e)
            return RedirectResponse(
                url="/portal/admin/users?error=" + quote_plus("Failed to set password"),
                status_code=302,
            )

        note = "Temporary password set; user must change on next login" if not desired_permanent else "Password set"
        msg = f"{note}: {email}"
        return RedirectResponse(
            url="/portal/admin/users?success=" + quote_plus(msg),
            status_code=302,
        )

    # ========== Clusters Routes ==========

    @router.get("/portal/clusters", response_class=HTMLResponse)
    async def portal_clusters(request: Request):
        """Clusters page - shows ParallelCluster instances across regions."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        customer, _ = _get_customer_for_session(request, deps)

        # Fetch cluster information
        clusters = []
        regions = []
        error = None
        # Check if user is admin to determine if we should fetch SSH status
        is_admin = bool(request.session.get("is_admin", False))
        create_mode = request.query_params.get("action") == "create"
        prefill_region = request.query_params.get("region")
        try:
            from daylib.cluster_service import get_cluster_service
            from daylib.ursa_config import get_ursa_config

            # Use UrsaConfig for regions (preferred) with fallback to legacy env var
            ursa_config = get_ursa_config()
            if ursa_config.is_configured:
                allowed_regions = ursa_config.get_allowed_regions()
                aws_profile = ursa_config.aws_profile or deps.settings.aws_profile
            else:
                allowed_regions = deps.settings.get_allowed_regions()
                aws_profile = deps.settings.aws_profile

            regions = allowed_regions or []
            if prefill_region and prefill_region not in regions:
                prefill_region = None

            if allowed_regions:
                # Use global singleton to share cache across requests
                service = get_cluster_service(
                    regions=allowed_regions,
                    aws_profile=aws_profile,
                    cache_ttl_seconds=300,
                )
                # Only fetch SSH status for admin users
                all_clusters = service.get_all_clusters_with_status(
                    fetch_ssh_status=is_admin,
                )
                clusters = [c.to_dict(include_sensitive=is_admin) for c in all_clusters]
        except Exception as e:
            LOGGER.error(f"Failed to fetch clusters: {e}")
            error = str(e)

        return deps.templates.TemplateResponse(
            request,
            "clusters.html",
            _get_template_context(
                request, deps,
                customer=customer,
                clusters=clusters,
                regions=regions,
                error=error,
                active_page="clusters",
                is_admin=is_admin,  # Explicitly pass to ensure template matches fetch_ssh_status
                create_mode=create_mode,
                prefill_region=prefill_region,
            ),
        )

    # ========== Monitor API Endpoints (for AJAX) ==========

    @router.get("/api/monitor/status")
    async def api_monitor_status(request: Request):
        """Get monitor status as JSON for AJAX updates."""
        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        _require_admin(request)
        import os

        config_dir = Path.home() / ".ursa"
        pid_file = config_dir / "monitor.pid"

        # Check if monitor is running
        monitor_pid = None
        monitor_running = False
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
                os.kill(pid, 0)
                monitor_pid = pid
                monitor_running = True
            except (ValueError, ProcessLookupError, PermissionError):
                pass

        # Get workset statistics from TapDB
        stats = {
            "in_progress": 0,
            "ready": 0,
            "complete": 0,
            "error": 0,
        }
        try:
            for ws_state in WorksetState:
                batch = deps.state_db.list_worksets_by_state(ws_state, limit=500)
                count = len(batch)
                if ws_state == WorksetState.IN_PROGRESS:
                    stats["in_progress"] = count
                elif ws_state == WorksetState.READY:
                    stats["ready"] = count
                elif ws_state == WorksetState.COMPLETE:
                    stats["complete"] = count
                elif ws_state == WorksetState.ERROR:
                    stats["error"] = count
        except Exception as e:
            LOGGER.warning(f"Failed to get workset stats: {e}")

        return {
            "running": monitor_running,
            "pid": monitor_pid,
            "stats": stats,
        }

    @router.get("/api/monitor/logs")
    async def api_monitor_logs(
        request: Request,
        lines: int = Query(100, ge=10, le=500),
        level: Optional[str] = Query(None),
    ):
        """Get recent monitor log lines as JSON for AJAX updates."""

        auth_redirect = _require_portal_auth(request)
        if auth_redirect:
            return auth_redirect
        _require_admin(request)

        config_dir = Path.home() / ".ursa"
        log_dir = config_dir / "logs"

        # Get latest log file
        log_files = sorted(log_dir.glob("monitor_*.log"), reverse=True) if log_dir.exists() else []
        if not log_files:
            return {"lines": [], "error": None, "log_file": None}

        latest_log = log_files[0]
        log_lines = []
        error = None

        try:
            with latest_log.open("r", encoding="utf-8", errors="replace") as f:
                all_lines = f.readlines()
                log_lines = [line.rstrip() for line in all_lines[-lines:]]

                # Filter by level if specified
                if level:
                    log_lines = [line for line in log_lines if f"[{level}]" in line]
        except Exception as e:
            LOGGER.warning("Failed to read log file %s: %s", latest_log.name, e)
            error = "Failed to read log file"

        return {
            "lines": log_lines,
            "error": error,
            "log_file": str(latest_log.name),
        }

    return router
